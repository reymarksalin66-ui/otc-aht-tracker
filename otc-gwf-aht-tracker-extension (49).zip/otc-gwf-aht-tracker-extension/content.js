(function () {
    'use strict';

    // ═══════════════════════════════════════════════════════════════════
    // 🔒 URL & IFRAME VALIDATION (v3.3.14)
    // ═══════════════════════════════════════════════════════════════════

    if (window.self !== window.top) {
        console.log('⚠️ [AHT TRACKER] Running in iframe, skipping initialization');
        return;
    }

    if (!window.location.href.includes('/hz/')) {
        console.log('⚠️ [AHT TRACKER] Page does not match required pattern, skipping');
        return;
    }

    if (window.AHT_TRACKER_INITIALIZED) {
        console.log('⚠️ [AHT TRACKER] Already initialized on this page, skipping');
        return;
    }
    window.AHT_TRACKER_INITIALIZED = true;

    console.log('═══════════════════════════════════════════════════════');
    console.log('  🚀 AHT TRACKER v3.3.14 - CHROME EXTENSION');
    console.log('═══════════════════════════════════════════════════════');

    // ═══════════════════════════════════════════════════════════════════
    // 📋 CONFIGURATION
    // ═══════════════════════════════════════════════════════════════════

    const CONFIG = {
        storage: {
            log: 'aht_case_log_v3',
            position: 'aht_panel_position_v3',
            size: 'aht_panel_size_v3',
            timer: 'aht_timer_state_v3',
            minimized: 'aht_panel_minimized_v3',
            goals: 'aht_goals_v3',
            excluded: 'aht_excluded_entries_v3',
            unloadState: 'aht_unload_state_v3'
        },
        defaults: { email: 4.5 * 60, nonemail: 8.02 * 60, photon: 8.02 * 60, muckout: 2.17 * 60, muckoutBac: 0.91 * 60, muckoutRcc: 1.00 * 60, muckoutMa: 1.42 * 60, muckoutRe: 2.17 * 60, photoncore: 1.0 * 60 },
        patterns: {
            email: /(claims-atoz-inquiries-sesu|trms-pi-claims-cs-escalation-claims|claims-asor-inquiries-sss)@amazon\.[a-z.]+/i,
            photon: /(trms_pi_ph_uw_otc_fallback_uow|photon.*fallback|fallback.*photon)/i,
            muckout: /What is the reason for the claim being filed\?[\s\S]{0,500}(?:Return Shipping fee|Custom fee|Re-?stocking [Ff]ee)|For Action on Muckout Claim|Is there a related claim filed on the order[\s\S]{0,200}Check the Claim Timeline widget|Does the buyer have any signs of Abuse[\s\S]{0,500}Returnless Refunds Abuse(?![\s\S]{0,100}DNR Abuse)/i
        },
        timers: { updateFrequency: 1000, panelRebuild: 500, caseChangeDelay: 1500, undoWindow: 30000 },
        photonCoreQueues: [
            { name: 'Claim Reason', goal: 0.97 * 60, patterns: [/What is the reason for the claim being filed/i, /NOTR.*Other than NOTR/is, /CBBS.*thoroughly/i] },
            { name: 'NOTR Followup Details', goal: 2.05 * 60, patterns: [/What is the reason for the claim being filed/i, /NOTR.*Other than NOTR/is] },
            { name: 'DIFF Claim Reason Check', goal: 1.12 * 60, patterns: [/What is the reason for the claim being filed/i, /Confirmed Matdiff/i, /CBBS/i] },
            { name: 'DIFF Follow Up', goal: 1.18 * 60, patterns: [/What is the reason for the claim being filed/i, /Confirmed Matdiff/i] },
            { name: 'Buyer DNR Abuse Check', goal: 0.63 * 60, patterns: [/Does the buyer has signs of Delivered Not Receive \(DNR\) Abuse/i] },
            { name: 'Counterfeit MatDiff Check', goal: 0.65 * 60, patterns: [/Does seller.s profile have any counterfeit trends/i, /at least 3.*verified CCR complaints/i] },
            { name: 'Tracking Shipping Address', goal: 2.72 * 60, patterns: [/Did Seller issue refund/i] },
            { name: 'Appeals Validation', goal: 2.33 * 60, patterns: [/Is the Appeal valid/i] },
            { name: 'ASIN Details', goal: 0.68 * 60, patterns: [/Is the ASIN returnable in the Amazon marketplace/i] },
            { name: 'DIFF FTC Manual Action', goal: 1.10 * 60, patterns: [/Photon Suggested Action for DIFF/i] },
            { name: 'DIFF Buyer MDR Abuse Check', goal: 0.75 * 60, patterns: [/Does the buyer have any signs of Abuse/i, /Non-Sellable Returns Abuse/i, /Materially Different Returns Abuse/i, /MFN Claims Abuse/i, /Returnless Refunds Abuse/i, /DNR Abuse/i] },
            { name: 'NOTR Appeals Follow Up', goal: 2.83 * 60, patterns: [/Is the previous action taken on the claim valid/i] },
            { name: 'MSS Abuse Check', goal: 0.85 * 60, patterns: [/Identify if seller has signs of MSS abuse/i] },
            { name: 'DIFF Return Window Check', goal: 0.83 * 60, patterns: [/Is buyer.s first contact within the marketplace return window/i] },
            { name: 'NOTR FTC Manual Action', goal: 0.90 * 60, patterns: [/Photon Suggested Action for NOTR/i] },
            { name: 'DIFF Return Details', goal: 1.83 * 60, patterns: [/Did buyer raise a return request/i] },
            { name: 'DIFF Return Replacement Details', goal: 2.40 * 60, patterns: [/Did the buyer and seller agree on a replacement/i] }
        ],
        ui: { panelWidth: 260, minWidth: 240, minHeight: 320, zIndex: 99999 }
    };

    const STARTUP_DELAY_SECONDS = 10;

    // ═══════════════════════════════════════════════════════════════════
    // 🔧 STORAGE LAYER (chrome.storage.local - synchronous cache)
    // ═══════════════════════════════════════════════════════════════════

    // We use an in-memory cache for synchronous access, synced to chrome.storage.local
    const _storageCache = {};
    let _storageCacheReady = false;

    function _initStorageCache() {
        return new Promise((resolve) => {
            const keys = Object.values(CONFIG.storage);
            chrome.storage.local.get(keys, (result) => {
                for (const [k, v] of Object.entries(result)) {
                    _storageCache[k] = v;
                }
                _storageCacheReady = true;
                resolve();
            });
        });
    }

    function safeGetStorage(key, defaultValue = null) {
        try {
            const value = _storageCache[key];
            if (value === null || value === undefined) return defaultValue;
            const parsed = typeof value === 'string' ? JSON.parse(value) : value;
            if (key === CONFIG.storage.log || key === CONFIG.storage.excluded) {
                if (!Array.isArray(parsed)) return [];
                if (parsed.length > 20000) return parsed.slice(-20000);
            }
            return parsed;
        } catch (e) {
            console.error(`❌ [STORAGE ERROR] Failed to retrieve '${key}':`, e.message);
            return defaultValue;
        }
    }

    function safeSetStorage(key, value) {
        try {
            let stringValue = typeof value === 'string' ? value : JSON.stringify(value);
            JSON.parse(stringValue); // validate
            _storageCache[key] = stringValue;
            chrome.storage.local.set({ [key]: stringValue });
            return true;
        } catch (e) {
            console.error(`❌ [STORAGE SAVE ERROR] Failed to save '${key}':`, e.message);
            return false;
        }
    }

    function validateLogEntry(entry) {
        if (!entry || typeof entry !== 'object') return null;
        try {
            return {
                caseId: String(entry.caseId || 'UNKNOWN').substring(0, 100),
                caseType: ['email', 'nonemail', 'photon', 'muckout', 'photoncore'].includes(entry.caseType) ? entry.caseType : 'nonemail',
                queueName: String(entry.queueName || '').substring(0, 200),
                duration: Math.max(0, parseInt(entry.duration) || 0),
                formatted: formatTime(Math.max(0, parseInt(entry.duration) || 0)),
                goal: Math.max(60, parseInt(entry.goal) || CONFIG.defaults.nonemail),
                dag: Math.max(0, Math.min(999.9, parseFloat(entry.dag) || 0)),
                startTime: entry.startTime || new Date().toISOString(),
                timestamp: entry.timestamp || new Date().toISOString(),
                note: String(entry.note || '').substring(0, 100)
            };
        } catch (e) { return null; }
    }

    function loadLogSafely() {
        try {
            const raw = safeGetStorage(CONFIG.storage.log, []);
            if (!Array.isArray(raw)) return [];
            return raw.map(validateLogEntry).filter(e => e !== null);
        } catch (e) { return []; }
    }

    // ═══════════════════════════════════════════════════════════════════
    // ⭐ ENTRY EXCLUSION MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════

    function getEntryKey(caseId, timestamp) { return `${caseId}|${timestamp}`; }
    function loadExcludedEntries() { return safeGetStorage(CONFIG.storage.excluded, []) || []; }
    function saveExcludedEntries(list) { return safeSetStorage(CONFIG.storage.excluded, JSON.stringify(list)); }

    function toggleEntryExclusion(caseId, timestamp) {
        const excluded = loadExcludedEntries();
        const key = getEntryKey(caseId, timestamp);
        const idx = excluded.indexOf(key);
        if (idx > -1) excluded.splice(idx, 1);
        else excluded.push(key);
        saveExcludedEntries(excluded);
        return excluded;
    }

    function findDuplicateCases(log) {
        const map = {};
        for (const entry of log) {
            if (!map[entry.caseId]) map[entry.caseId] = [];
            map[entry.caseId].push(entry);
        }
        return Object.entries(map).filter(([, v]) => v.length > 1).map(([caseId, instances]) => ({ caseId, count: instances.length, instances }));
    }

    function autoExcludeDuplicates() {
        const log = loadLogSafely();
        const duplicates = findDuplicateCases(log);
        if (duplicates.length === 0) { alert('✅ No duplicate cases found!'); return false; }
        let excluded = 0;
        const excludedEntries = loadExcludedEntries();
        for (const dup of duplicates) {
            const instances = dup.instances.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
            for (let i = 1; i < instances.length; i++) {
                const key = getEntryKey(instances[i].caseId, instances[i].timestamp);
                if (!excludedEntries.includes(key)) { excludedEntries.push(key); excluded++; }
            }
        }
        saveExcludedEntries(excludedEntries);
        return true;
    }


    // ═══════════════════════════════════════════════════════════════════
    // 🧹 CLEANUP HANDLERS
    // ═══════════════════════════════════════════════════════════════════

    const CLEANUP_HANDLERS = [];
    function registerCleanup(fn) { if (typeof fn === 'function') CLEANUP_HANDLERS.push(fn); }
    function executeCleanup() {
        CLEANUP_HANDLERS.forEach((fn) => { try { fn(); } catch (e) {} });
    }
    window.addEventListener('unload', executeCleanup);

    // ═══════════════════════════════════════════════════════════════════
    // ⭐ UNDO HISTORY
    // ═══════════════════════════════════════════════════════════════════

    let undoTimer = null, lastDeletedEntry = null, undoButtonVisible = false;

    function saveToUndoHistory(entry) {
        lastDeletedEntry = entry;
        undoButtonVisible = true;
        showUndoButton();
        if (undoTimer) clearTimeout(undoTimer);
        undoTimer = setTimeout(() => { lastDeletedEntry = null; undoButtonVisible = false; hideUndoButton(); }, CONFIG.timers.undoWindow);
    }

    function undoLastDelete() {
        if (!lastDeletedEntry) { alert('⚠️ Nothing to undo!'); return; }
        const log = loadLogSafely();
        log.push(lastDeletedEntry);
        if (safeSetStorage(CONFIG.storage.log, JSON.stringify(log))) {
            lastDeletedEntry = null; undoButtonVisible = false; hideUndoButton();
            if (undoTimer) clearTimeout(undoTimer);
            updateStatusMsg('✅ Restored!', '#2ecc71');
            setTimeout(() => updateStatusMsg('Tracking...', '#aaa'), 2000);
            const lp = document.getElementById('aht-log-panel');
            if (lp && lp.style.display !== 'none') renderLog();
        }
    }

    function showUndoButton() {
        const btn = document.getElementById('aht-btn-undo');
        if (btn) { btn.style.display = 'block'; btn.style.animation = 'pulse 0.5s infinite'; }
    }
    function hideUndoButton() {
        const btn = document.getElementById('aht-btn-undo');
        if (btn) btn.style.display = 'none';
    }

    // ═══════════════════════════════════════════════════════════════════
    // ⭐ DAILY/WEEKLY STATS
    // ═══════════════════════════════════════════════════════════════════

    function getTodayDate() { return new Date().toISOString().slice(0, 10); }
    function getDateDaysAgo(days) { const d = new Date(); d.setDate(d.getDate() - days); return d.toISOString().slice(0, 10); }
    function getWeekStartDate() {
        const now = new Date(); const dow = now.getDay();
        const diff = now.getDate() - dow + (dow === 0 ? -6 : 1);
        return new Date(now.setDate(diff)).toISOString().slice(0, 10);
    }
    function getDateFromTimestamp(ts) { return new Date(ts).toISOString().slice(0, 10); }

    function calcStatsForDateRange(log, startDate, endDate) {
        if (!Array.isArray(log) || log.length === 0) return null;
        const excluded = loadExcludedEntries();
        const filtered = log.filter(e => {
            const d = getDateFromTimestamp(e.timestamp);
            return d >= startDate && d <= endDate && !excluded.includes(getEntryKey(e.caseId, e.timestamp));
        });
        if (filtered.length === 0) return null;
        let eC = 0, nC = 0, pC = 0, mC = 0, pcC = 0, eT = 0, nT = 0, pT = 0, mT = 0, pcT = 0, mGoalSum = 0, pcGoalSum = 0;
        for (const e of filtered) {
            const dur = Math.max(0, parseInt(e.duration) || 0);
            if (e.caseType === 'email') { eC++; eT += dur; }
            else if (e.caseType === 'photon') { pC++; pT += dur; }
            else if (e.caseType === 'muckout') { mC++; mT += dur; mGoalSum += (e.goal || CONFIG.defaults.muckout); }
            else if (e.caseType === 'photoncore') { pcC++; pcT += dur; pcGoalSum += (e.goal || CONFIG.defaults.photoncore); }
            else { nC++; nT += dur; }
        }
        const total = eC + nC + pC + mC + pcC;
        if (total === 0) return null;
        const eW = eC/total, nW = nC/total, pW = pC/total, mW = mC/total, pcW = pcC/total;
        const aE = eC > 0 ? eT/eC : 0, aN = nC > 0 ? nT/nC : 0, aP = pC > 0 ? pT/pC : 0, aM = mC > 0 ? mT/mC : 0, aPC = pcC > 0 ? pcT/pcC : 0;
        const mGoalAvg = mC > 0 ? mGoalSum/mC : CONFIG.defaults.muckout;
        const pcGoalAvg = pcC > 0 ? pcGoalSum/pcC : CONFIG.defaults.photoncore;
        const eD = eC > 0 ? ((AHT_GOALS.email/aE)*100).toFixed(1) : null;
        const nD = nC > 0 ? ((AHT_GOALS.nonemail/aN)*100).toFixed(1) : null;
        const pD = pC > 0 ? ((AHT_GOALS.photon/aP)*100).toFixed(1) : null;
        const mD = mC > 0 ? ((mGoalAvg/aM)*100).toFixed(1) : null;
        const pcD = pcC > 0 ? ((pcGoalAvg/aPC)*100).toFixed(1) : null;
        const wG = AHT_GOALS.email*eW + AHT_GOALS.nonemail*nW + AHT_GOALS.photon*pW + mGoalAvg*mW + pcGoalAvg*pcW;
        const wA = aE*eW + aN*nW + aP*pW + aM*mW + aPC*pcW;
        const wD = wA > 0 ? ((wG/wA)*100).toFixed(1) : null;
        return { startDate, endDate, caseCount: total, emailCount: eC, nonEmailCount: nC, photonCount: pC, muckoutCount: mC, photoncoreCount: pcC,
            avgEmailAHT: aE, avgNonEmailAHT: aN, avgPhotonAHT: aP, avgMuckoutAHT: aM, avgPhotoncoreAHT: aPC,
            avgMuckoutGoal: mGoalAvg, avgPhotoncoreGoal: pcGoalAvg,
            emailDAG: eD, nonEmailDAG: nD, photonDAG: pD, muckoutDAG: mD, photoncoreDAG: pcD,
            weightedDAG: wD, weightedGoalAHT: wG, weightedAchievedAHT: wA, totalDuration: eT+nT+pT+mT+pcT };
    }

    function getTodayStats() { const l = loadLogSafely(), t = getTodayDate(); return calcStatsForDateRange(l, t, t); }
    function getWeekStats() { return calcStatsForDateRange(loadLogSafely(), getWeekStartDate(), getTodayDate()); }
    function getMonthStats() { const t = getTodayDate(); return calcStatsForDateRange(loadLogSafely(), t.slice(0,8)+'01', t); }
    function getLast7DaysStats() { return calcStatsForDateRange(loadLogSafely(), getDateDaysAgo(6), getTodayDate()); }

    // ═══════════════════════════════════════════════════════════════════
    // 📊 STATE VARIABLES
    // ═══════════════════════════════════════════════════════════════════

    let AHT_GOALS = { ...CONFIG.defaults };
    let timerInterval = null, mutationObserver = null, rebuildTimeout = null, urlCheckTimeout = null;
    let startTime = null, elapsedSeconds = 0, isRunning = false;
    let currentCaseId = null, isCaseIdValid = false;
    let currentCaseType = 'nonemail', currentQueueName = '', caseStartTimestamp = null;
    let currentGoal = CONFIG.defaults.nonemail;
    let isDragging = false, dragOffsetX = 0, dragOffsetY = 0;
    let isResizing = false, resizeStartX = 0, resizeStartY = 0, resizeStartWidth = 0, resizeStartHeight = 0;
    let helpPanelOpen = false, isMinimized = false, goalsEditorOpen = false, statsEditorOpen = false;
    let pageLoadInitialized = false, manuallyStoppedOnCase = null, stoppedAtZero = false;
    let shouldAutoStartOnLoad = true, lastUrl = location.href, lastSavedCaseId = null;
    let trackingEnabled = true;
    let idleTimeout = null, lastActivity = Date.now();
    const IDLE_MINUTES = 10;
    let currentTheme = 'dark';
    let compactMode = false;

    const DOM = { panel: null, display: null, bar: null, dag: null, statusMsg: null, caseLabel: null, queueLabel: null, badge: null, goalLabel: null, minimizedDisplay: null };

    function cacheDOMElements() {
        DOM.panel = document.getElementById('aht-tracker-panel');
        DOM.display = document.getElementById('aht-timer-display');
        DOM.bar = document.getElementById('aht-status-bar');
        DOM.dag = document.getElementById('aht-dag-display');
        DOM.statusMsg = document.getElementById('aht-status-msg');
        DOM.caseLabel = document.getElementById('aht-case-label');
        DOM.queueLabel = document.getElementById('aht-queue-label');
        DOM.badge = document.getElementById('aht-case-type-badge');
        DOM.goalLabel = document.getElementById('aht-goal-label');
        DOM.minimizedDisplay = document.getElementById('aht-minimized-timer-display');
    }


    // ═══════════════════════════════════════════════════════════════════
    // 🎯 GOALS MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════

    function loadGoals() {
        try {
            const stored = safeGetStorage(CONFIG.storage.goals, null);
            if (stored && typeof stored === 'object') {
                AHT_GOALS = {
                    email: Math.max(60, parseInt(stored.email) || CONFIG.defaults.email),
                    nonemail: Math.max(60, parseInt(stored.nonemail) || CONFIG.defaults.nonemail),
                    photon: Math.max(60, parseInt(stored.photon) || CONFIG.defaults.photon),
                    muckout: Math.max(30, parseInt(stored.muckout) || CONFIG.defaults.muckout),
                    muckoutBac: Math.max(30, parseFloat(stored.muckoutBac) * 60 || CONFIG.defaults.muckoutBac),
                    muckoutRcc: Math.max(30, parseFloat(stored.muckoutRcc) * 60 || CONFIG.defaults.muckoutRcc),
                    muckoutMa: Math.max(30, parseFloat(stored.muckoutMa) * 60 || CONFIG.defaults.muckoutMa),
                    muckoutRe: Math.max(30, parseFloat(stored.muckoutRe) * 60 || CONFIG.defaults.muckoutRe),
                    photoncore: Math.max(30, parseInt(stored.photoncore) || CONFIG.defaults.photoncore)
                };
                // Restore photon core queue goals
                if (stored.photonCoreGoals && Array.isArray(stored.photonCoreGoals)) {
                    stored.photonCoreGoals.forEach((g, i) => {
                        if (CONFIG.photonCoreQueues[i] && g > 0) CONFIG.photonCoreQueues[i].goal = g;
                    });
                }
                return;
            }
        } catch (e) {}
        AHT_GOALS = { ...CONFIG.defaults };
    }

    function saveGoals() {
        const goalsData = { ...AHT_GOALS, photonCoreGoals: CONFIG.photonCoreQueues.map(q => q.goal) };
        safeSetStorage(CONFIG.storage.goals, JSON.stringify(goalsData));
    }

    function resetGoalsToDefault() {
        AHT_GOALS = { ...CONFIG.defaults };
        saveGoals(); updateGoalsUI(); updateCaseTypeUI();
        if (DOM.display) DOM.display.style.color = '#00d4ff';
        updateStatusMsg('✅ Goals reset', '#2ecc71');
    }

    // ═══════════════════════════════════════════════════════════════════
    // 🧭 CASE DETECTION
    // ═══════════════════════════════════════════════════════════════════

    function isValidCaseId(caseId) {
        if (!caseId || typeof caseId !== 'string') return false;
        const trimmed = caseId.trim();
        if (trimmed.length < 3) return false;
        if (trimmed.includes('UNKNOWN') || trimmed.startsWith('UNKNOWN-')) return false;
        return true;
    }

    function normalizeAndCompareCaseIds(a, b) {
        return String(a || '').trim().toLowerCase() === String(b || '').trim().toLowerCase();
    }

    function detectCaseId() {
        const detectors = [
            () => new URLSearchParams(window.location.search).get('caseId'),
            () => new URLSearchParams(window.location.search).get('id'),
            () => {
                const entityId = new URLSearchParams(window.location.search).get('entityId');
                if (entityId) { const m = entityId.match(/^(\d+):/); if (m) return m[1]; }
                return null;
            },
            () => { const m = window.location.href.match(/\/(cases|investigation|view-case)\/([A-Z0-9\-]+)/i); return m ? m[2] : null; }
        ];
        for (const d of detectors) {
            try { const r = d(); if (r && String(r).length > 3) return String(r).substring(0, 100); } catch (e) {}
        }
        return null;
    }

    function detectCaseType() {
        // Get page text - temporarily hide panel to exclude its text
        const panel = document.getElementById('aht-tracker-panel');
        if (panel) panel.style.display = 'none';
        const bodyText = document.body ? (document.body.innerText || '') : '';
        if (panel) panel.style.display = '';
        const bodyHTML = document.body ? (document.body.innerHTML || '') : '';
        const entityType = new URLSearchParams(window.location.search).get('entityType');

        // Check muckout FIRST (before photon, since they share same URL pattern)
        // But ONLY if URL indicates UnitOfWork (photon/muckout URL format)
        // Exclude photon core pages (which have "NOTR" or "Other than NOTR")
        const hasNOTRDIFFOptions = /NOTR[\s\S]{0,500}DIFF[\s\S]{0,500}Remorse/i.test(bodyText) || /NOTR[\s\S]{0,500}DIFF[\s\S]{0,500}Remorse/i.test(bodyHTML);
        const isMuckoutPage = entityType === 'UnitOfWork' && !hasNOTRDIFFOptions && !/DNR Abuse/i.test(bodyText) && !/DNR Abuse/i.test(bodyHTML) && (CONFIG.patterns.muckout.test(bodyText) || CONFIG.patterns.muckout.test(bodyHTML));
        if (isMuckoutPage) {
            currentCaseType = 'muckout';
            if (/For Action on Muckout Claim/i.test(bodyText) || /For Action on Muckout Claim/i.test(bodyHTML)) {
                currentQueueName = 'Muckout - Manual Action';
                AHT_GOALS.muckout = AHT_GOALS.muckoutMa;
            } else if (/Does the buyer have any signs of Abuse[\s\S]{0,500}Returnless Refunds Abuse/i.test(bodyText) && !/DNR Abuse/i.test(bodyText)) {
                currentQueueName = 'Muckout - Buyer Abuse Check';
                AHT_GOALS.muckout = AHT_GOALS.muckoutBac;
            } else if (/Is there a related claim filed on the order.*Check the Claim Timeline widget/is.test(bodyText) || /Is there a related claim filed on the order.*Check the Claim Timeline widget/is.test(bodyHTML)) {
                currentQueueName = 'Muckout - Related Claim Check';
                AHT_GOALS.muckout = AHT_GOALS.muckoutRcc;
            } else {
                currentQueueName = 'Muckout - Claim Reason Refund Eligibility Check';
                AHT_GOALS.muckout = AHT_GOALS.muckoutRe;
            }
            console.log('✅ [CASE TYPE] Detected MUCKOUT:', currentQueueName);
            return currentCaseType;
        }

        if (entityType === 'UnitOfWork') {
            // Check photon core queues
            const content = bodyText + ' ' + bodyHTML;
            for (const q of CONFIG.photonCoreQueues) {
                if (q.patterns.every(p => p.test(content))) {
                    currentCaseType = 'photoncore';
                    currentQueueName = 'Photon Core - ' + q.name;
                    AHT_GOALS.photoncore = q.goal;
                    console.log('✅ [CASE TYPE] Detected PHOTON CORE:', currentQueueName);
                    return currentCaseType;
                }
            }
            currentCaseType = 'photon'; currentQueueName = 'Fallback (UnitOfWork)';
            console.log('✅ [CASE TYPE] Detected FALLBACK');
            return currentCaseType;
        }

        const queuePatterns = [/Queue[:\s]+([^\r\n<]+)/i, /Queue Name[:\s]+([^\r\n<]+)/i, /Assigned Queue[:\s]+([^\r\n<]+)/i];
        let queueName = '';
        for (const p of queuePatterns) {
            const m = bodyText.match(p);
            if (m && m[1].trim().length > 5 && !m[1].includes('&') && !m[1].includes('<')) {
                queueName = m[1].trim().substring(0, 200);
                break;
            }
        }
        // Fallback: try to find workflow name
        if (!queueName) {
            const wfMatch = bodyText.match(/pi_claims_\w+/i);
            if (wfMatch) queueName = wfMatch[0];
        }
        // Fallback: search for known email/photon queue patterns anywhere in HTML
        if (!queueName || !CONFIG.patterns.email.test(queueName)) {
            const emailMatch = bodyHTML.match(/(claims-atoz-inquiries-sesu|trms-pi-claims-cs-escalation-claims|claims-asor-inquiries-sss)@amazon\.[a-z.]+/i);
            if (emailMatch) {
                queueName = emailMatch[0];
                console.log('✅ [CASE TYPE] Found email queue in HTML:', queueName);
            }
        }
        if (!queueName || (!CONFIG.patterns.email.test(queueName) && !CONFIG.patterns.photon.test(queueName))) {
            const photonMatch = bodyHTML.match(/(trms_pi_ph_uw_otc_fallback_uow)/i);
            if (photonMatch) {
                queueName = photonMatch[0];
                console.log('✅ [CASE TYPE] Found photon queue in HTML:', queueName);
            }
        }
        currentQueueName = queueName;
        if (CONFIG.patterns.photon.test(currentQueueName)) currentCaseType = 'photon';
        else if (CONFIG.patterns.email.test(currentQueueName)) currentCaseType = 'email';
        else currentCaseType = 'nonemail';
        console.log('✅ [CASE TYPE] Detected:', currentCaseType, '| Queue:', currentQueueName);
        return currentCaseType;
    }



    // ═══════════════════════════════════════════════════════════════════
    // ⏱ TIME FORMATTING & CALCULATIONS
    // ═══════════════════════════════════════════════════════════════════

    function formatTime(seconds) {
        seconds = Math.max(0, parseInt(seconds) || 0);
        return Math.floor(seconds/60).toString().padStart(2,'0') + ':' + (seconds%60).toString().padStart(2,'0');
    }
    function secondsToMinutes(s) { return parseFloat((Math.max(0, parseInt(s)||0)/60).toFixed(2)); }
    function calcDAG(actual, type) {
        if (actual === 0) return null;
        const goal = (type === currentCaseType) ? currentGoal : AHT_GOALS[type];
        return Math.min(999.9, (goal/actual)*100).toFixed(1);
    }

    function calcWeightedStats(log) {
        if (!Array.isArray(log) || log.length === 0) return null;
        const stats = calcStatsForDateRange(log, '1970-01-01', '2099-12-31');
        if (!stats) return null;
        return { weightedDAG: stats.weightedDAG, weightedGoalAHT: stats.weightedGoalAHT,
            weightedAchievedAHT: stats.weightedAchievedAHT, totalCases: stats.caseCount,
            emailCount: stats.emailCount, nonEmailCount: stats.nonEmailCount, photonCount: stats.photonCount,
            avgEmail: stats.avgEmailAHT, avgNonEmail: stats.avgNonEmailAHT, avgPhoton: stats.avgPhotonAHT,
            emailDAG: stats.emailDAG, nonEmailDAG: stats.nonEmailDAG, photonDAG: stats.photonDAG,
            excludedCount: log.length - stats.caseCount };
    }

    // ═══════════════════════════════════════════════════════════════════
    // ⭐ TIMER MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════

    function startTimer() {
        if (!trackingEnabled) { updateStatusMsg('⏸ Offline - not tracking', '#7f8c8d'); return; }
        if (!isCaseIdValid) { updateStatusMsg('❌ Case ID not detected', '#e74c3c'); setButtonStates(false); return; }
        if (isRunning) return;
        if (timerInterval !== null) { clearInterval(timerInterval); timerInterval = null; }
        refreshCaseType();
        isRunning = true;
        caseStartTimestamp = new Date().toISOString();
        currentGoal = AHT_GOALS[currentCaseType];
        // Timer starts from 0 (no compensation on clock)
        startTime = Date.now() - (elapsedSeconds * 1000);
        timerInterval = setInterval(() => {
            try {
                elapsedSeconds = Math.floor((Date.now() - startTime) / 1000);
                if (!isDragging && !isResizing) {
                    updateDisplay();
                    if (elapsedSeconds % 30 === 0) updateTodayQuick();
                    saveTimerState();
                }
            } catch (e) {}
        }, CONFIG.timers.updateFrequency);
        registerCleanup(() => { if (timerInterval !== null) { clearInterval(timerInterval); timerInterval = null; } });
        setButtonStates(true);
        updateStatusMsg('🟢 Tracking...', '#2ecc71');
        if (DOM.display) DOM.display.classList.add('tracking');
        saveTimerState(true);
    }

    function stopTimer() {
        if (timerInterval !== null) { clearInterval(timerInterval); timerInterval = null; }
        isRunning = false;
        const compensated = elapsedSeconds + STARTUP_DELAY_SECONDS;
        const dag = calcDAG(compensated, currentCaseType);
        if (isCaseIdValid && (lastSavedCaseId !== currentCaseId || elapsedSeconds === 0)) {
            saveLog(dag); lastSavedCaseId = currentCaseId;
        }
        manuallyStoppedOnCase = currentCaseId;
        stoppedAtZero = (elapsedSeconds === 0);
        updateStatusMsg(`✅ Saved | DAG: ${dag}%`, '#00d4ff');
        setButtonStates(false); saveTimerState(true);
        elapsedSeconds = 0; caseStartTimestamp = null;
        if (DOM.display) { DOM.display.textContent = '00:00'; DOM.display.style.color = '#00d4ff'; DOM.display.classList.remove('tracking'); }
        if (DOM.bar) { DOM.bar.style.width = '0%'; DOM.bar.style.background = '#00d4ff'; }
        if (DOM.dag) DOM.dag.textContent = 'DAG: —';
        updateStatusMsg('⏸ Timer paused', '#aaa');
        updateTodayQuick();
    }

    // ═══════════════════════════════════════════════════════════════════
    // 💾 TIMER STATE PERSISTENCE
    // ═══════════════════════════════════════════════════════════════════

    // Throttle storage saves - only write timer state every 5 seconds
    let _lastTimerSave = 0;
    function saveTimerState(force = false) {
        const now = Date.now();
        if (!force && now - _lastTimerSave < 5000) return;
        _lastTimerSave = now;
        safeSetStorage(CONFIG.storage.timer, JSON.stringify({
            isRunning, startTime, caseId: currentCaseId, caseType: currentCaseType,
            queueName: currentQueueName, caseStartTimestamp, stoppedAtZero, lastSavedCaseId, savedAt: now,
            activeGoal: currentGoal
        }));
    }

    function restoreTimerState() {
        try {
            const ts = safeGetStorage(CONFIG.storage.timer, null);
            if (!ts) return false;
            if (!normalizeAndCompareCaseIds(ts.caseId, currentCaseId)) {
                safeSetStorage(CONFIG.storage.timer, JSON.stringify({ isRunning: false })); return false;
            }
            // For photon/muckout/photoncore: if same case but different queue, reset timer
            // Only compare if both queue names are non-empty (detection may not have run yet)
            if (['photon', 'muckout', 'photoncore'].includes(ts.caseType) || ['photon', 'muckout', 'photoncore'].includes(currentCaseType)) {
                if (ts.queueName && currentQueueName && ts.queueName.length > 5 && currentQueueName.length > 5 && ts.queueName !== currentQueueName) {
                    console.log(`🔄 [TIMER] Same case, different queue: ${ts.queueName} → ${currentQueueName}. Resetting.`);
                    safeSetStorage(CONFIG.storage.timer, JSON.stringify({ isRunning: false }));
                    return false;
                }
            }
            if (ts.stoppedAtZero === true) {
                safeSetStorage(CONFIG.storage.timer, JSON.stringify({ isRunning: false }));
                shouldAutoStartOnLoad = false; return false;
            }
            if (ts.isRunning && ts.startTime) {
                startTime = ts.startTime;
                elapsedSeconds = Math.floor((Date.now() - ts.startTime) / 1000);
                isRunning = true; currentCaseId = ts.caseId; currentCaseType = ts.caseType;
                currentQueueName = ts.queueName; caseStartTimestamp = ts.caseStartTimestamp;
                stoppedAtZero = false; shouldAutoStartOnLoad = false; manuallyStoppedOnCase = null;
                lastSavedCaseId = ts.lastSavedCaseId || null;
                if (ts.activeGoal) { currentGoal = ts.activeGoal; AHT_GOALS[ts.caseType] = ts.activeGoal; }
                return true;
            }
        } catch (e) {}
        return false;
    }


    // ═══════════════════════════════════════════════════════════════════
    // ⭐ UNLOAD STATE MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════

    function saveUnloadState() {
        if (isRunning && elapsedSeconds > 0 && isCaseIdValid) {
            const noteEl = document.getElementById('aht-case-note');
            const note = noteEl ? noteEl.value.trim().substring(0, 100) : '';
            safeSetStorage(CONFIG.storage.unloadState, JSON.stringify({
                caseId: currentCaseId, caseType: currentCaseType, queueName: currentQueueName,
                elapsedSeconds, caseStartTimestamp, timestamp: Date.now(), note
            }));
        }
    }

    function restoreAndLogUnloadState() {
        try {
            const us = safeGetStorage(CONFIG.storage.unloadState, null);
            if (!us) return;
            const newCaseId = detectCaseId();
            const newValid = isValidCaseId(newCaseId);
            if (newValid && isCaseIdValid && normalizeAndCompareCaseIds(us.caseId, newCaseId)) {
                safeSetStorage(CONFIG.storage.unloadState, null); return;
            }
            const compensated = us.elapsedSeconds + STARTUP_DELAY_SECONDS;
            const dag = calcDAG(us.elapsedSeconds, us.caseType);
            const entry = validateLogEntry({
                caseId: us.caseId, caseType: us.caseType, queueName: us.queueName,
                duration: compensated, formatted: formatTime(compensated),
                goal: AHT_GOALS[us.caseType], dag, startTime: us.caseStartTimestamp, timestamp: new Date().toISOString(),
                note: us.note || ''
            });
            if (entry) {
                const log = loadLogSafely(); log.push(entry);
                safeSetStorage(CONFIG.storage.log, JSON.stringify(log));
            }
            safeSetStorage(CONFIG.storage.unloadState, null);
        } catch (e) {}
    }

    // ═══════════════════════════════════════════════════════════════════
    // 📊 DISPLAY UPDATES
    // ═══════════════════════════════════════════════════════════════════

    function updateDisplay() {
        if (!DOM.display) cacheDOMElements();
        if (!DOM.display) return;
        const goal = currentGoal;
        const timeStr = formatTime(elapsedSeconds);
        DOM.display.textContent = timeStr;
        if (DOM.minimizedDisplay) DOM.minimizedDisplay.textContent = timeStr;
        const pct = Math.min((elapsedSeconds / goal) * 100, 100);
        if (DOM.bar) DOM.bar.style.width = pct + '%';
        const dag = calcDAG(elapsedSeconds + STARTUP_DELAY_SECONDS, currentCaseType);
        // Update minimized info
        const miniInfo = document.getElementById('aht-minimized-info');
        if (miniInfo && dag !== null) {
            const typeLabel = currentCaseType === 'email' ? 'Email' : currentCaseType === 'photon' ? 'Fallback' : currentCaseType === 'muckout' ? 'Muckout' : currentCaseType === 'photoncore' ? 'Core' : 'Non-Email';
            miniInfo.textContent = `${typeLabel} | DAG: ${dag}%`;
            miniInfo.style.color = parseFloat(dag) >= 100 ? '#2ecc71' : parseFloat(dag) >= 80 ? '#f39c12' : '#e74c3c';
        }
        if (dag !== null && DOM.dag) {
            const dv = parseFloat(dag);
            const dc = dv >= 100 ? '#2ecc71' : dv >= 80 ? '#f39c12' : '#e74c3c';
            DOM.dag.textContent = `DAG: ${dag}%`; DOM.dag.style.color = dc;
        }
        if (elapsedSeconds >= goal) {
            DOM.display.style.color = '#e74c3c';
            if (DOM.minimizedDisplay) DOM.minimizedDisplay.style.color = '#e74c3c';
            if (DOM.bar) DOM.bar.style.background = '#e74c3c';
            updateStatusMsg('🚨 AHT Critical!', '#e74c3c');
            // Flash at exactly goal time
            if (elapsedSeconds === goal) { DOM.panel && (DOM.panel.style.boxShadow = '0 0 20px #e74c3c'); setTimeout(() => { if (DOM.panel) DOM.panel.style.boxShadow = '0 4px 20px rgba(0,0,0,0.5)'; }, 1000); }
        } else if (elapsedSeconds >= goal * 0.75) {
            DOM.display.style.color = '#f39c12';
            if (DOM.minimizedDisplay) DOM.minimizedDisplay.style.color = '#f39c12';
            if (DOM.bar) DOM.bar.style.background = '#f39c12';
            updateStatusMsg('⚠️ Approaching goal', '#f39c12');
            // Flash at exactly 75%
            if (elapsedSeconds === Math.floor(goal * 0.75)) { DOM.panel && (DOM.panel.style.boxShadow = '0 0 15px #f39c12'); setTimeout(() => { if (DOM.panel) DOM.panel.style.boxShadow = '0 4px 20px rgba(0,0,0,0.5)'; }, 800); }
        } else {
            DOM.display.style.color = '#00d4ff';
            if (DOM.minimizedDisplay) DOM.minimizedDisplay.style.color = '#00d4ff';
            if (DOM.bar) DOM.bar.style.background = '#00d4ff';
            updateStatusMsg('🟢 Tracking...', '#2ecc71');
        }
    }

    function updateStatusMsg(msg, color = '#aaa') {
        if (!DOM.statusMsg) cacheDOMElements();
        if (DOM.statusMsg) { DOM.statusMsg.textContent = msg; DOM.statusMsg.style.color = color; }
    }

    function updateCaseTypeUI() {
        if (!DOM.badge) cacheDOMElements();
        if (!DOM.badge) return;
        if (!isCaseIdValid) {
            DOM.badge.textContent = '❌ Invalid'; DOM.badge.style.background = '#e74c3c';
            if (DOM.goalLabel) DOM.goalLabel.textContent = 'Case ID not detected';
            return;
        }
        const map = {
            email: { label: 'Email', bg: '#8e44ad', goal: `Goal: ${formatTime(AHT_GOALS.email)} (Email)` },
            photon: { label: 'Fallback', bg: '#c0392b', goal: `Goal: ${formatTime(AHT_GOALS.photon)} (Fallback)` },
            muckout: { label: 'Muckout', bg: '#e67e22', goal: `Goal: ${formatTime(AHT_GOALS.muckout)} (Muckout)` },
            photoncore: { label: 'Photon Core', bg: '#9b59b6', goal: `Goal: ${formatTime(AHT_GOALS.photoncore)} (Photon Core)` },
            nonemail: { label: 'Non-Email', bg: '#2980b9', goal: `Goal: ${formatTime(AHT_GOALS.nonemail)} (Non-Email)` }
        };
        const t = map[currentCaseType] || map.nonemail;
        DOM.badge.textContent = t.label; DOM.badge.style.background = t.bg;
        if (DOM.goalLabel) DOM.goalLabel.textContent = t.goal;
        if (DOM.queueLabel) DOM.queueLabel.textContent = currentQueueName ? `Queue: ${currentQueueName}` : 'Queue: detecting...';
    }

    function refreshCaseType() { detectCaseType(); currentGoal = AHT_GOALS[currentCaseType]; updateCaseTypeUI(); }
    function setButtonStates(running) { const btn = document.getElementById('aht-btn-stop'); if (btn) btn.disabled = !running; }

    // ═══════════════════════════════════════════════════════════════════
    // 💾 LOGGING & EXPORT
    // ═══════════════════════════════════════════════════════════════════

    function saveLog(dag) {
        if (!isCaseIdValid) return;
        const log = loadLogSafely();
        const compensated = elapsedSeconds + STARTUP_DELAY_SECONDS;
        const noteEl = document.getElementById('aht-case-note');
        const note = noteEl ? noteEl.value.trim().substring(0, 100) : '';
        const entry = validateLogEntry({
            caseId: currentCaseId, caseType: currentCaseType, queueName: currentQueueName,
            duration: compensated, formatted: formatTime(compensated),
            goal: currentGoal, dag, startTime: caseStartTimestamp, timestamp: new Date().toISOString(),
            note: note
        });
        if (entry) {
            log.push(entry);
            safeSetStorage(CONFIG.storage.log, JSON.stringify(log));
            if (noteEl) noteEl.value = '';
            // Warn when approaching storage limit
            if (log.length === 15000) {
                showToast('⚠️ 15,000 entries stored — consider exporting and clearing old data', '#f39c12', 8000);
            } else if (log.length === 19000) {
                showToast('🚨 19,000 entries — oldest data will be auto-deleted soon! Export now.', '#e74c3c', 10000);
            }
        }
    }


    function renderStatsPanel() {
        const sp = document.getElementById('aht-stats-panel');
        if (!sp) return;

        // Get selected dates or default to current
        const dayInput = document.getElementById('aht-stats-day-input');
        const weekInput = document.getElementById('aht-stats-week-input');
        const monthInput = document.getElementById('aht-stats-month-input');
        const selectedDay = dayInput ? dayInput.value : getTodayDate();
        const selectedWeek = weekInput ? weekInput.value : getTodayDate();
        const selectedMonth = monthInput ? monthInput.value : getTodayDate().slice(0, 7);

        // Calculate week range from selected date (Sunday to Saturday)
        const weekDate = new Date(selectedWeek + 'T00:00:00');
        const dow = weekDate.getDay();
        const weekStart = new Date(weekDate);
        weekStart.setDate(weekDate.getDate() - dow);
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekStart.getDate() + 6);
        const weekStartStr = weekStart.toISOString().slice(0, 10);
        const weekEndStr = weekEnd.toISOString().slice(0, 10);

        // Month range
        const monthStart = selectedMonth + '-01';
        const monthEndDate = new Date(parseInt(selectedMonth.slice(0,4)), parseInt(selectedMonth.slice(5,7)), 0);
        const monthEnd = monthEndDate.toISOString().slice(0, 10);

        const log = loadLogSafely();
        const todayStats = calcStatsForDateRange(log, selectedDay, selectedDay);
        const weekStats = calcStatsForDateRange(log, weekStartStr, weekEndStr);
        const monthStats = calcStatsForDateRange(log, monthStart, monthEnd);

        const dc = (dag) => { if (!dag) return '#aaa'; const v = parseFloat(dag); return v >= 100 ? '#2ecc71' : v >= 80 ? '#f39c12' : '#e74c3c'; };
        const box = (label, stats, range) => {
            if (!stats) return `<div style="background:#16213e;border-radius:6px;padding:8px;margin-bottom:8px;opacity:0.5;"><div style="color:#aaa;font-size:11px;font-weight:bold;">📊 ${label}</div><div style="color:#888;font-size:10px;">No data for ${range}</div></div>`;
            const gwfCount = stats.emailCount + stats.nonEmailCount;
            const photonCount = stats.photonCount + (stats.muckoutCount || 0) + (stats.photoncoreCount || 0);
            let gwfDAG = null, photonDAG = null;
            if (gwfCount > 0) {
                const eW = stats.emailCount / gwfCount, nW = stats.nonEmailCount / gwfCount;
                const gwfGoal = AHT_GOALS.email * eW + AHT_GOALS.nonemail * nW;
                const gwfActual = (stats.avgEmailAHT || 0) * eW + (stats.avgNonEmailAHT || 0) * nW;
                if (gwfActual > 0) gwfDAG = ((gwfGoal / gwfActual) * 100).toFixed(1);
            }
            if (photonCount > 0) {
                const pW = stats.photonCount / photonCount, mW = (stats.muckoutCount || 0) / photonCount, pcW = (stats.photoncoreCount || 0) / photonCount;
                const mGoal = stats.avgMuckoutGoal || AHT_GOALS.muckout;
                const pcGoal = stats.avgPhotoncoreGoal || AHT_GOALS.photoncore;
                const pGoal = AHT_GOALS.photon * pW + mGoal * mW + pcGoal * pcW;
                const pActual = (stats.avgPhotonAHT || 0) * pW + (stats.avgMuckoutAHT || 0) * mW + (stats.avgPhotoncoreAHT || 0) * pcW;
                if (pActual > 0) photonDAG = ((pGoal / pActual) * 100).toFixed(1);
            }
            return `<div style="background:#16213e;border-radius:6px;padding:8px;margin-bottom:8px;border-left:4px solid #00d4ff;">
                <div style="color:#00d4ff;font-size:11px;font-weight:bold;">📊 ${label}</div>
                <div style="color:#aaa;font-size:10px;margin-top:4px;">
                    <strong>Cases:</strong> GWF: ${gwfCount} (📧${stats.emailCount} + 📁${stats.nonEmailCount}) | Photon: ${photonCount} (⚛${stats.photonCount} + 🔧${stats.muckoutCount || 0} + 💜${stats.photoncoreCount || 0}) = <strong>${stats.caseCount}</strong><br>
                    <strong>Overall DAG:</strong> <span style="color:${dc(stats.weightedDAG)};font-weight:bold;">${stats.weightedDAG}%</span><br>
                    ${gwfDAG ? `<strong>GWF DAG:</strong> <span style="color:${dc(gwfDAG)}">${gwfDAG}%</span>` : ''}
                    ${photonDAG ? ` | <strong>Photon DAG:</strong> <span style="color:${dc(photonDAG)}">${photonDAG}%</span>` : ''}
                </div></div>`;
        };
        sp.innerHTML = `<div style="background:#0f0f1a;border-radius:8px;padding:8px;font-size:11px;color:#ddd;">
            <div style="background:#16213e;border-radius:6px;padding:8px;margin-bottom:10px;border-left:4px solid #16a085;">
                <div style="color:#16a085;font-weight:bold;font-size:12px;">📈 STATS</div>
                <div style="color:#aaa;font-size:9px;">Select date/week/month to view stats</div>
            </div>
            <div style="margin-bottom:8px;">
                <label style="color:#aaa;font-size:9px;">Day:</label>
                <input id="aht-stats-day-input" type="date" value="${selectedDay}" style="width:100%;padding:4px;border:1px solid #444;border-radius:4px;background:#1a1a2e;color:#00d4ff;font-size:10px;box-sizing:border-box;margin-top:2px;"/>
            </div>
            ${box('DAY: ' + selectedDay, todayStats, selectedDay)}
            <div style="margin-bottom:8px;">
                <label style="color:#aaa;font-size:9px;">Week (pick any day in the week):</label>
                <input id="aht-stats-week-input" type="date" value="${selectedWeek}" style="width:100%;padding:4px;border:1px solid #444;border-radius:4px;background:#1a1a2e;color:#00d4ff;font-size:10px;box-sizing:border-box;margin-top:2px;"/>
            </div>
            ${box('WEEK: ' + weekStartStr + ' to ' + weekEndStr, weekStats, weekStartStr + ' to ' + weekEndStr)}
            <div style="margin-bottom:8px;">
                <label style="color:#aaa;font-size:9px;">Month:</label>
                <input id="aht-stats-month-input" type="month" value="${selectedMonth}" style="width:100%;padding:4px;border:1px solid #444;border-radius:4px;background:#1a1a2e;color:#00d4ff;font-size:10px;box-sizing:border-box;margin-top:2px;"/>
            </div>
            ${box('MONTH: ' + selectedMonth, monthStats, monthStart + ' to ' + monthEnd)}
        </div>`;
        // Attach change listeners to re-render on date change
        setTimeout(() => {
            ['aht-stats-day-input', 'aht-stats-week-input', 'aht-stats-month-input'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.addEventListener('change', renderStatsPanel);
            });
        }, 50);
    }

    function renderLog() {
        const logPanel = document.getElementById('aht-log-panel');
        if (!logPanel) return;
        const log = loadLogSafely();
        if (log.length === 0) { logPanel.innerHTML = '<em>No cases logged yet.</em>'; return; }
        const excluded = loadExcludedEntries();
        const stats = calcWeightedStats(log);
        const duplicates = findDuplicateCases(log);
        const dc = (dag) => { const v = parseFloat(dag); return v >= 100 ? '#2ecc71' : v >= 80 ? '#f39c12' : '#e74c3c'; };
        let dupWarn = '';
        if (duplicates.length > 0) {
            const totalDups = duplicates.reduce((s, d) => s + (d.count - 1), 0);
            dupWarn = `<div style="background:#c0392b;border-radius:6px;padding:8px;margin-bottom:8px;border-left:4px solid #e74c3c;">
                <div style="color:#fff;font-size:11px;font-weight:bold;">⚠️ FOUND ${duplicates.length} DUPLICATE CASE(S) (${totalDups} extra)</div>
                <button id="aht-btn-auto-exclude-dups" style="background:#f1c40f;color:#000;border:none;border-radius:4px;padding:6px 10px;cursor:pointer;font-size:10px;font-weight:bold;margin-top:4px;">🔄 Auto-Exclude Dups</button>
            </div>`;
        }
        const rows = log.slice(-15).reverse().map(entry => {
            const key = getEntryKey(entry.caseId, entry.timestamp);
            const isExcl = excluded.includes(key);
            const tl = entry.caseType === 'email' ? 'Email' : entry.caseType === 'photon' ? 'Fallback' : entry.caseType === 'muckout' ? 'Muckout' : entry.caseType === 'photoncore' ? 'Photon Core' : 'Non-Email';
            const tb = entry.caseType === 'email' ? '#8e44ad' : entry.caseType === 'photon' ? '#c0392b' : entry.caseType === 'muckout' ? '#e67e22' : entry.caseType === 'photoncore' ? '#9b59b6' : '#2980b9';
            return `<div style="border-bottom:1px solid ${isExcl?'#444':'#222'};padding:4px 0;${isExcl?'opacity:0.5;background:#0a0a14;':''}">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:2px;">
                    <div style="flex:1;"><span style="font-weight:bold;${isExcl?'text-decoration:line-through;':''}">${entry.caseId}</span>
                        <span style="font-size:9px;padding:1px 5px;border-radius:8px;background:${tb};color:#fff;margin-left:4px;">${tl}</span>
                        ${isExcl?'<span style="font-size:9px;color:#e74c3c;margin-left:4px;">⊘ EXCLUDED</span>':''}
                    </div>
                    <div>
                        <button class="aht-exclude-btn" data-caseid="${entry.caseId}" data-ts="${entry.timestamp}" style="background:${isExcl?'#27ae60':'#e74c3c'};color:#fff;border:none;border-radius:4px;padding:2px 6px;cursor:pointer;font-size:9px;font-weight:bold;">${isExcl?'✓ Included':'✗ Exclude'}</button>
                        <button class="aht-delete-btn" data-caseid="${entry.caseId}" data-ts="${entry.timestamp}" style="background:#e74c3c;color:#fff;border:none;border-radius:4px;padding:2px 6px;cursor:pointer;font-size:9px;font-weight:bold;margin-left:2px;">🗑 Delete</button>
                    </div>
                </div>
                <div style="font-size:10px;color:#aaa;">⏱ ${entry.formatted} | <span style="color:${dc(entry.dag)}">DAG: ${entry.dag}%</span> | ${new Date(entry.timestamp).toLocaleTimeString()}</div>
                ${entry.note ? `<div style="font-size:9px;color:#f39c12;margin-top:1px;">📝 ${entry.note}</div>` : ''}
            </div>`;
        }).join('');
        logPanel.innerHTML = `
            <div style="background:#16213e;border-radius:6px;padding:8px;margin-bottom:8px;font-size:11px;">
                <div style="color:#00d4ff;font-weight:bold;margin-bottom:4px;">📋 CASE LOG</div>
                <div style="color:#aaa;font-size:10px;"><strong>Total:</strong> ${log.length} | <strong style="color:#e74c3c;">Excluded:</strong> ${excluded.length}</div>
                ${stats?`<div style="color:#aaa;margin-top:4px;"><strong>Weighted DAG: <span style="color:${parseFloat(stats.weightedDAG)>=100?'#2ecc71':'#f39c12'}">${stats.weightedDAG}%</span></strong></div>`:''}
            </div>
            ${dupWarn}
            <div style="background:#0f0f1a;border-radius:6px;padding:8px;margin-bottom:8px;border-left:4px solid #f39c12;">
                <div style="font-size:10px;color:#f39c12;font-weight:bold;">✗ Exclude / ✓ Include</div>
                <div style="font-size:9px;color:#aaa;">Click button to exclude/include this specific entry</div>
            </div>
            <div style="color:#aaa;font-size:10px;margin-bottom:4px;">Last 15 cases (most recent first):</div>
            ${rows}`;
        setTimeout(() => {
            const adBtn = document.getElementById('aht-btn-auto-exclude-dups');
            if (adBtn) adBtn.addEventListener('click', () => { if (autoExcludeDuplicates()) { renderLog(); updateStatusMsg('✅ Duplicates excluded!', '#2ecc71'); } });
            logPanel.querySelectorAll('.aht-exclude-btn').forEach(btn => {
                btn.addEventListener('click', () => { toggleEntryExclusion(btn.dataset.caseid, btn.dataset.ts); renderLog(); });
            });
            logPanel.querySelectorAll('.aht-delete-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    if (confirm('Delete this entry? You have 30 seconds to undo.')) {
                        const entry = log.find(e => e.caseId === btn.dataset.caseid && e.timestamp === btn.dataset.ts);
                        const updated = log.filter(e => !(e.caseId === btn.dataset.caseid && e.timestamp === btn.dataset.ts));
                        safeSetStorage(CONFIG.storage.log, JSON.stringify(updated));
                        if (entry) saveToUndoHistory(entry);
                        renderLog();
                    }
                });
            });
        }, 100);
    }

    function exportToExcel(fromDate, toDate) {
        try {
            let log = loadLogSafely();
            if (log.length === 0) { alert('No cases logged yet.'); return; }
            // Filter by date range if provided
            if (fromDate && toDate) {
                log = log.filter(e => {
                    const d = new Date(e.timestamp).toISOString().slice(0, 10);
                    return d >= fromDate && d <= toDate;
                });
                if (log.length === 0) { alert('No cases in selected date range.'); return; }
            }
            const excluded = loadExcludedEntries();
            const stats = calcWeightedStats(log);
            const wb = XLSX.utils.book_new();
            const caseRows = log.map((e, i) => ({
                '#': i+1, 'Date': new Date(e.timestamp).toLocaleDateString(), 'Time': new Date(e.timestamp).toLocaleTimeString(),
                'Case ID': e.caseId, 'Type': e.caseType==='email'?'Email':e.caseType==='photon'?'Fallback':e.caseType==='muckout'?'Muckout':e.caseType==='photoncore'?'Photon Core':'Non-Email',
                'Queue': (e.caseType === 'muckout' || e.caseType === 'photoncore') ? e.queueName : '',
                'AHT (mm:ss)': e.formatted, 'AHT (min)': secondsToMinutes(e.duration), 'DAG %': parseFloat(e.dag),
                'Excluded?': excluded.includes(getEntryKey(e.caseId, e.timestamp)) ? 'YES' : 'NO',
                'Note': e.note || ''
            }));
            const ws1 = XLSX.utils.json_to_sheet(caseRows);
            ws1['!cols'] = [{wch:4},{wch:12},{wch:12},{wch:18},{wch:12},{wch:35},{wch:12},{wch:10},{wch:10},{wch:10}];
            XLSX.utils.book_append_sheet(wb, ws1, 'Case Log');
            if (stats) {
                const ts = getTodayStats(), ws2data = getWeekStats();
                // Calculate GWF and Photon sub-DAGs
                const allStats = calcStatsForDateRange(log, '1970-01-01', '2099-12-31');
                let gwfDAG = 'N/A', photonDAG = 'N/A', emailDAG = 'N/A', nonEmailDAG = 'N/A', fallbackDAG = 'N/A', muckoutDAG = 'N/A';
                if (allStats) {
                    emailDAG = allStats.emailDAG || 'N/A';
                    nonEmailDAG = allStats.nonEmailDAG || 'N/A';
                    fallbackDAG = allStats.photonDAG || 'N/A';
                    muckoutDAG = allStats.muckoutDAG || 'N/A';
                    const gwfCount = allStats.emailCount + allStats.nonEmailCount;
                    if (gwfCount > 0) {
                        const eW = allStats.emailCount/gwfCount, nW = allStats.nonEmailCount/gwfCount;
                        const gwfGoal = AHT_GOALS.email*eW + AHT_GOALS.nonemail*nW;
                        const gwfActual = (allStats.avgEmailAHT||0)*eW + (allStats.avgNonEmailAHT||0)*nW;
                        if (gwfActual > 0) gwfDAG = ((gwfGoal/gwfActual)*100).toFixed(1);
                    }
                    const pCount = allStats.photonCount + (allStats.muckoutCount||0);
                    if (pCount > 0) {
                        const pW = allStats.photonCount/pCount, mW = (allStats.muckoutCount||0)/pCount;
                        const mGoal = allStats.avgMuckoutGoal || AHT_GOALS.muckout;
                        const pGoal = AHT_GOALS.photon*pW + mGoal*mW;
                        const pActual = (allStats.avgPhotonAHT||0)*pW + (allStats.avgMuckoutAHT||0)*mW;
                        if (pActual > 0) photonDAG = ((pGoal/pActual)*100).toFixed(1);
                    }
                }
                const summaryRows = [
                    {Metric:'Export Date',Value:new Date().toLocaleString()},{Metric:'',Value:''},
                    {Metric:'TOTAL CASES',Value:log.length},{Metric:'Excluded',Value:excluded.length},
                    {Metric:'Included',Value:log.length-excluded.length},{Metric:'',Value:''},
                    {Metric:'TODAY',Value:getTodayDate()},{Metric:'Cases Today',Value:ts?.caseCount||0},
                    {Metric:'Today DAG %',Value:ts?.weightedDAG||'N/A'},{Metric:'',Value:''},
                    {Metric:'THIS WEEK',Value:getWeekStartDate()+' to '+getTodayDate()},
                    {Metric:'Week Cases',Value:ws2data?.caseCount||0},{Metric:'Week DAG %',Value:ws2data?.weightedDAG||'N/A'},
                    {Metric:'',Value:''},{Metric:'OVERALL',Value:''},{Metric:'Total (Included)',Value:stats.totalCases},
                    {Metric:'Overall Weighted DAG %',Value:parseFloat(stats.weightedDAG)},
                    {Metric:'Status',Value:parseFloat(stats.weightedDAG)>=100?'Achieved ✓':'Below Goal ✗'},
                    {Metric:'',Value:''},{Metric:'--- GWF ---',Value:''},
                    {Metric:'GWF DAG %',Value:gwfDAG},{Metric:'Email DAG %',Value:emailDAG},{Metric:'Non-Email DAG %',Value:nonEmailDAG},
                    {Metric:'',Value:''},{Metric:'--- PHOTON ---',Value:''},
                    {Metric:'Photon DAG %',Value:photonDAG},{Metric:'Fallback DAG %',Value:fallbackDAG},{Metric:'Muckout DAG %',Value:muckoutDAG}
                ];
                const ws2 = XLSX.utils.json_to_sheet(summaryRows);
                ws2['!cols'] = [{wch:35},{wch:20}];
                XLSX.utils.book_append_sheet(wb, ws2, 'Summary');
            }
            XLSX.writeFile(wb, `AHT_Log_${new Date().toISOString().slice(0,10)}.xlsx`);
            updateStatusMsg('✅ Exported to Excel', '#2ecc71');
        } catch (e) { console.error('❌ Export error:', e); alert('Export failed.'); }
    }

    function exportToCSV() {
        const log = loadLogSafely();
        if (log.length === 0) { alert('No cases logged yet.'); return; }
        const excluded = loadExcludedEntries();
        const header = 'Date,Time,Case ID,Type,Queue,AHT (mm:ss),AHT (min),DAG %,Excluded,Note';
        const rows = log.map(e => {
            const type = e.caseType==='email'?'Email':e.caseType==='photon'?'Fallback':e.caseType==='muckout'?'Muckout':e.caseType==='photoncore'?'Photon Core':'Non-Email';
            const queue = (e.caseType === 'muckout' || e.caseType === 'photoncore') ? e.queueName : '';
            const excl = excluded.includes(getEntryKey(e.caseId, e.timestamp)) ? 'YES' : 'NO';
            return `${new Date(e.timestamp).toLocaleDateString()},${new Date(e.timestamp).toLocaleTimeString()},${e.caseId},${type},"${queue}",${e.formatted},${secondsToMinutes(e.duration)},${e.dag},${excl},"${(e.note||'').replace(/"/g,'')}"`;
        });
        const csv = [header, ...rows].join('\n');
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = url; a.download = `AHT_Log_${getTodayDate()}.csv`;
        a.click(); URL.revokeObjectURL(url);
        updateStatusMsg('✅ Exported CSV', '#2ecc71');
    }

    // ═══════════════════════════════════════════════════════════════════
    // 🎨 UI - PANEL STATE & MINIMIZE
    // ═══════════════════════════════════════════════════════════════════

    function loadPanelState() {
        const pos = safeGetStorage(CONFIG.storage.position, { bottom: "20px", right: "20px" });
        const size = safeGetStorage(CONFIG.storage.size, { width: "260px", height: "auto" });
        return { position: pos || { bottom: "20px", right: "20px" }, size: size || { width: "260px", height: "auto" } };
    }

    function savePanelState(panel) {
        if (!panel) return;
        try {
            const r = panel.getBoundingClientRect();
            safeSetStorage(CONFIG.storage.position, JSON.stringify({ bottom: `${window.innerHeight-r.bottom}px`, right: `${window.innerWidth-r.right}px`, top:'auto', left:'auto' }));
            safeSetStorage(CONFIG.storage.size, JSON.stringify({ width: `${r.width}px`, height: `${r.height}px` }));
        } catch (e) {}
    }

    function loadMinimizedState() { const s = safeGetStorage(CONFIG.storage.minimized, false); return s === true || s === 'true'; }
    function saveMinimizedState(m) { safeSetStorage(CONFIG.storage.minimized, m ? 'true' : 'false'); isMinimized = m; }

    function toggleMinimize() {
        const panel = document.getElementById('aht-tracker-panel'), header = document.getElementById('aht-panel-header');
        const content = document.getElementById('aht-panel-content'), btn = document.getElementById('aht-btn-minimize');
        const mini = document.getElementById('aht-minimized-section');
        if (!panel || !content || !btn || !header) return;
        isMinimized = !isMinimized; saveMinimizedState(isMinimized);
        if (isMinimized) {
            content.style.display = 'none'; if (mini) mini.style.display = 'flex';
            btn.textContent = '📍 Expand'; header.style.borderRadius = '12px';
            panel.style.height = 'auto'; panel.style.minHeight = 'auto';
        } else {
            content.style.display = 'flex'; if (mini) mini.style.display = 'none';
            btn.textContent = '📌 Min'; header.style.borderRadius = '12px 12px 0 0';
            panel.style.height = ''; panel.style.minHeight = '320px';
        }
    }

    function closeAllPanels(except) {
        const panels = ['aht-log-panel', 'aht-stats-panel', 'aht-help-panel', 'aht-goals-editor-panel', 'aht-export-panel'];
        panels.forEach(id => { if (id !== except) { const el = document.getElementById(id); if (el) el.style.display = 'none'; } });
        if (except !== 'aht-log-panel') { const lp = document.getElementById('aht-log-panel'); if (lp) lp.style.display = 'none'; }
        if (except !== 'aht-goals-editor-panel') goalsEditorOpen = false;
        if (except !== 'aht-stats-panel') statsEditorOpen = false;
        if (except !== 'aht-help-panel') helpPanelOpen = false;
    }

    function toggleGoalsEditor() {
        const gp = document.getElementById('aht-goals-editor-panel');
        if (!gp) return;
        goalsEditorOpen = !goalsEditorOpen;
        if (goalsEditorOpen) closeAllPanels('aht-goals-editor-panel');
        gp.style.display = goalsEditorOpen ? 'block' : 'none';
        if (goalsEditorOpen) updateGoalsUI();
    }

    function toggleStatsPanel() {
        const sp = document.getElementById('aht-stats-panel');
        if (!sp) return;
        statsEditorOpen = !statsEditorOpen;
        if (statsEditorOpen) closeAllPanels('aht-stats-panel');
        sp.style.display = statsEditorOpen ? 'block' : 'none';
        if (statsEditorOpen) renderStatsPanel();
    }

    function updateGoalsUI() {
        const eI = document.getElementById('aht-goal-email-input');
        const nI = document.getElementById('aht-goal-nonemail-input');
        const pI = document.getElementById('aht-goal-photon-input');
        const mbI = document.getElementById('aht-goal-muckout-bac-input');
        const mrI = document.getElementById('aht-goal-muckout-rcc-input');
        const mmI = document.getElementById('aht-goal-muckout-ma-input');
        const meI = document.getElementById('aht-goal-muckout-re-input');
        if (eI) eI.value = (AHT_GOALS.email / 60).toFixed(2);
        if (nI) nI.value = (AHT_GOALS.nonemail / 60).toFixed(2);
        if (pI) pI.value = (AHT_GOALS.photon / 60).toFixed(2);
        if (mbI) mbI.value = (AHT_GOALS.muckoutBac / 60).toFixed(2);
        if (mrI) mrI.value = (AHT_GOALS.muckoutRcc / 60).toFixed(2);
        if (mmI) mmI.value = (AHT_GOALS.muckoutMa / 60).toFixed(2);
        if (meI) meI.value = (AHT_GOALS.muckoutRe / 60).toFixed(2);
        // Populate photon core goals
        const pcList = document.getElementById('aht-photoncore-goals-list');
        if (pcList) {
            pcList.innerHTML = CONFIG.photonCoreQueues.map((q, i) => `
                <div><label style="color:#9b59b6;font-size:9px;display:block;margin-bottom:2px;font-weight:bold;">${q.name}:</label>
                    <input id="aht-goal-pc-${i}" type="number" step="0.01" min="0.1" max="60" value="${(q.goal / 60).toFixed(2)}" style="width:100%;padding:4px;border:1px solid #444;border-radius:4px;background:#1a1a2e;color:#9b59b6;font-size:10px;box-sizing:border-box;"/></div>
            `).join('');
        }
        // Attach folder toggles
        document.querySelectorAll('.aht-goal-folder').forEach(folder => {
            folder.onclick = () => {
                const target = document.getElementById(folder.dataset.target);
                if (target) target.style.display = target.style.display === 'none' ? 'grid' : 'none';
            };
        });
    }

    function saveGoalsFromInputs() {
        try {
            const eV = parseFloat(document.getElementById('aht-goal-email-input').value);
            const nV = parseFloat(document.getElementById('aht-goal-nonemail-input').value);
            const pV = parseFloat(document.getElementById('aht-goal-photon-input').value);
            const mbV = parseFloat(document.getElementById('aht-goal-muckout-bac-input').value);
            const mrV = parseFloat(document.getElementById('aht-goal-muckout-rcc-input').value);
            const mmV = parseFloat(document.getElementById('aht-goal-muckout-ma-input').value);
            const meV = parseFloat(document.getElementById('aht-goal-muckout-re-input').value);
            const vals = [eV, nV, pV, mbV, mrV, mmV, meV];
            if (vals.some(v => isNaN(v) || v <= 0 || v > 60)) { alert('⚠️ All goals must be 0.1-60 minutes'); return false; }
            AHT_GOALS.email = eV*60; AHT_GOALS.nonemail = nV*60; AHT_GOALS.photon = pV*60;
            AHT_GOALS.muckoutBac = mbV*60; AHT_GOALS.muckoutRcc = mrV*60;
            AHT_GOALS.muckoutMa = mmV*60; AHT_GOALS.muckoutRe = meV*60;
            // Save photon core goals
            for (let i = 0; i < CONFIG.photonCoreQueues.length; i++) {
                const input = document.getElementById(`aht-goal-pc-${i}`);
                if (input) {
                    const v = parseFloat(input.value);
                    if (isNaN(v) || v <= 0 || v > 60) { alert(`⚠️ Photon Core "${CONFIG.photonCoreQueues[i].name}" must be 0.1-60 minutes`); return false; }
                    CONFIG.photonCoreQueues[i].goal = v * 60;
                }
            }
            saveGoals(); updateCaseTypeUI(); updateStatusMsg('✅ Goals saved!', '#2ecc71');
            return true;
        } catch (e) { return false; }
    }

    function displayHelpInstructions() {
        const hp = document.getElementById('aht-help-panel'), hb = document.getElementById('aht-btn-help');
        if (!hp || !hb) return;
        if (helpPanelOpen) { hp.style.display = 'none'; helpPanelOpen = false; hb.style.opacity = '1'; return; }
        closeAllPanels('aht-help-panel');
        helpPanelOpen = true; hb.style.opacity = '0.7';
        hp.innerHTML = `
            <div style="background:#16213e;border-radius:6px;padding:10px;margin-bottom:10px;border-left:4px solid #16a085;">
                <div style="color:#16a085;font-weight:bold;font-size:12px;">📖 AHT TRACKER v3.3.14 USER GUIDE</div>
            </div>
            <div style="margin-bottom:12px;"><div style="color:#00d4ff;font-weight:bold;">⏱ HOW IT WORKS</div>
                <div style="color:#bbb;font-size:10px;">• Timer starts automatically when you open a case<br>• Timer stops when you click ⏹ STOP or navigate to a different case<br>• Case type (Email/Non-Email/Fallback/Muckout) is detected automatically<br>• AHT and DAG% are calculated based on your goal settings</div></div>
            <div style="margin-bottom:12px;"><div style="color:#00d4ff;font-weight:bold;">📊 DAG% EXPLAINED</div>
                <div style="color:#bbb;font-size:10px;">• DAG = (Goal Time ÷ Your Time) × 100<br>• <span style="color:#2ecc71;">Green (100%+)</span> = You beat the goal<br>• <span style="color:#f39c12;">Yellow (80-99%)</span> = Close to goal<br>• <span style="color:#e74c3c;">Red (&lt;80%)</span> = Over goal time</div></div>
            <div style="margin-bottom:12px;"><div style="color:#00d4ff;font-weight:bold;">🔄 CASE SWITCHING</div>
                <div style="color:#bbb;font-size:10px;">• Opening a new case = previous case is saved automatically<br>• Page refresh = timer resumes (same case, no duplicate entry)<br>• Closing a case without clicking STOP = still logged</div></div>
            <div style="margin-bottom:12px;"><div style="color:#00d4ff;font-weight:bold;">📋 LOG & STATS</div>
                <div style="color:#bbb;font-size:10px;">• <strong>📋 Log</strong> — View last 15 cases, exclude/delete entries<br>• <strong>📊 Stats</strong> — Daily, weekly, monthly DAG breakdown<br>• <strong>📥 Export</strong> — Download full log as Excel file<br>• <strong>🗑 Clear</strong> — Erase all logged data</div></div>
            <div style="margin-bottom:12px;"><div style="color:#00d4ff;font-weight:bold;">⚙️ GOALS</div>
                <div style="color:#bbb;font-size:10px;">• Click ⚙️ Goals to set custom AHT targets (in minutes)<br>• Defaults: Email = 4.5 min | Non-Email = 8 min | Fallback = 8 min<br>• Goals affect DAG% calculation and progress bar</div></div>
            <div style="margin-bottom:12px;"><div style="color:#00d4ff;font-weight:bold;">🚫 EXCLUDE vs DELETE</div>
                <div style="color:#bbb;font-size:10px;">• <strong>Exclude</strong> — Hides entry from stats but keeps it in log<br>• <strong>Delete</strong> — Permanently removes entry (30s undo window)<br>• Use exclude for outliers you don't want in your averages</div></div>
            <div style="margin-bottom:12px;"><div style="color:#00d4ff;font-weight:bold;">📌 PANEL CONTROLS</div>
                <div style="color:#bbb;font-size:10px;">• Drag header to move panel<br>• Drag bottom-right corner to resize<br>• Click 📌 Min to minimize (timer still visible)<br>• Panel position is saved between sessions</div></div>
            <div style="background:#16213e;border-radius:6px;padding:8px;border-left:4px solid #f39c12;margin-top:10px;">
                <div style="color:#f39c12;font-size:10px;"><strong>⚠️ NOTE:</strong> The tracker only works on Paragon case pages. In the lobby, the badge shows "❌ Invalid" and no tracking occurs.<br><br><strong>⚠️ IMPORTANT:</strong> Always click ⏹ STOP before changing your aux status from Available. This ensures the last case is properly logged before the status change.</div>
            </div>`;
        hp.style.display = 'block';
    }


    // ═══════════════════════════════════════════════════════════════════
    // 🖼️ BUILD MAIN PANEL
    // ═══════════════════════════════════════════════════════════════════

    // ═══════════════════════════════════════════════════════════════════
    // 🔔 TOAST NOTIFICATIONS
    // ═══════════════════════════════════════════════════════════════════

    function showToast(msg, color = '#00d4ff', duration = 3000) {
        let toast = document.getElementById('aht-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'aht-toast';
            toast.style.cssText = 'position:fixed;top:20px;right:20px;padding:10px 16px;border-radius:8px;font-size:12px;font-weight:bold;z-index:999999;opacity:0;transition:opacity 0.3s;pointer-events:none;font-family:Arial,sans-serif;max-width:300px;';
            document.body.appendChild(toast);
        }
        toast.textContent = msg;
        toast.style.background = color;
        toast.style.color = '#fff';
        toast.style.opacity = '1';
        setTimeout(() => { toast.style.opacity = '0'; }, duration);
    }

    // ═══════════════════════════════════════════════════════════════════
    // ⏸ IDLE DETECTION
    // ═══════════════════════════════════════════════════════════════════

    function setupIdleDetection() {
        const resetIdle = () => { lastActivity = Date.now(); };
        ['mousemove', 'keydown', 'click', 'scroll'].forEach(e => document.addEventListener(e, resetIdle, { passive: true }));
        setInterval(() => {
            if (isRunning && (Date.now() - lastActivity) > IDLE_MINUTES * 60 * 1000) {
                stopTimer();
                showToast(`⏸ Timer paused — idle for ${IDLE_MINUTES} min`, '#f39c12', 5000);
                updateStatusMsg(`⏸ Idle pause (${IDLE_MINUTES}min)`, '#f39c12');
            }
        }, 30000);
    }

    // ═══════════════════════════════════════════════════════════════════
    // ⌨️ KEYBOARD SHORTCUTS
    // ═══════════════════════════════════════════════════════════════════

    function setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            if (e.altKey && e.key === 's') { e.preventDefault(); if (isRunning) stopTimer(); }
            if (e.altKey && e.key === 'm') { e.preventDefault(); toggleCompactMode(); }
        });
    }

    // ═══════════════════════════════════════════════════════════════════
    // 📊 TODAY'S QUICK STATS
    // ═══════════════════════════════════════════════════════════════════

    function getTodayCaseCount() {
        const log = loadLogSafely();
        const today = getTodayDate();
        const excluded = loadExcludedEntries();
        return log.filter(e => {
            const d = new Date(e.timestamp).toISOString().slice(0, 10);
            return d === today && !excluded.includes(getEntryKey(e.caseId, e.timestamp));
        }).length;
    }

    function updateTodayQuick() {
        const el = document.getElementById('aht-today-quick');
        if (!el) return;
        const count = getTodayCaseCount();
        const stats = getTodayStats();
        const dag = stats ? stats.weightedDAG + '%' : '—';
        const dagColor = stats ? (parseFloat(stats.weightedDAG) >= 100 ? '#2ecc71' : parseFloat(stats.weightedDAG) >= 80 ? '#f39c12' : '#e74c3c') : '#888';
        // Calculate streak
        const streak = calcDagStreak();
        const streakText = streak > 0 ? ` | 🔥${streak}d` : '';
        el.innerHTML = `📅 Today: <strong>${count}</strong> cases | DAG: <span style="color:${dagColor};font-weight:bold;">${dag}</span>${streakText}`;
    }

    function calcDagStreak() {
        const log = loadLogSafely();
        if (log.length === 0) return 0;
        let streak = 0;
        const today = new Date();
        for (let i = 0; i < 30; i++) {
            const d = new Date(today); d.setDate(d.getDate() - i);
            const dateStr = d.toISOString().slice(0, 10);
            const stats = calcStatsForDateRange(log, dateStr, dateStr);
            if (!stats) { if (i === 0) continue; break; }
            if (parseFloat(stats.weightedDAG) >= 100) streak++;
            else break;
        }
        return streak;
    }

    // ═══════════════════════════════════════════════════════════════════
    // 🎨 THEME TOGGLE
    // ═══════════════════════════════════════════════════════════════════

    function toggleTheme() {
        const panel = document.getElementById('aht-tracker-panel');
        if (!panel) return;
        currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
        safeSetStorage('aht_theme_v3', JSON.stringify(currentTheme));
        applyTheme(panel);
        showToast(currentTheme === 'dark' ? '🌙 Dark theme' : '☀️ Light theme', '#555', 2000);
    }

    function applyTheme(panel) {
        if (!panel) panel = document.getElementById('aht-tracker-panel');
        if (!panel) return;
        if (currentTheme === 'light') {
            panel.style.background = '#f5f5f5';
            panel.style.color = '#222';
            panel.style.border = '1px solid #ccc';
            panel.querySelectorAll('[style*="background:#0f0f1a"], [style*="background:#16213e"], [style*="background:#1a1a2e"]').forEach(el => {
                el.style.background = '#e8e8e8';
            });
        } else {
            panel.style.background = '#1a1a2e';
            panel.style.color = '#eaeaea';
            panel.style.border = '1px solid #333';
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    // 📌 PIN POSITION
    // ═══════════════════════════════════════════════════════════════════

    function pinToPosition(position) {
        const panel = document.getElementById('aht-tracker-panel');
        if (!panel) return;
        panel.style.top = 'auto'; panel.style.bottom = '20px';
        if (position === 'left') {
            panel.style.left = '20px'; panel.style.right = 'auto';
        } else {
            panel.style.right = '20px'; panel.style.left = 'auto';
        }
        safeSetStorage('aht_pin_position_v3', JSON.stringify(position));
        showToast(`📌 Pinned to ${position}`, '#555', 2000);
    }

    // ═══════════════════════════════════════════════════════════════════
    // 🔲 COMPACT MODE
    // ═══════════════════════════════════════════════════════════════════

    let compactInterval = null;

    function toggleCompactMode() {
        const panel = document.getElementById('aht-tracker-panel');
        if (!panel) return;
        compactMode = !compactMode;
        safeSetStorage('aht_compact_mode_v3', JSON.stringify(compactMode));
        if (compactInterval) { clearInterval(compactInterval); compactInterval = null; }
        if (compactMode) {
            panel.style.width = 'auto'; panel.style.minWidth = '80px'; panel.style.minHeight = 'auto';
            panel.style.borderRadius = '20px'; panel.style.padding = '0';
            panel.style.height = 'auto';
            // Snap to bottom-right
            panel.style.bottom = '20px'; panel.style.right = '20px';
            panel.style.top = 'auto'; panel.style.left = 'auto';
            panel.innerHTML = `<div id="aht-compact-view" style="padding:8px 14px;cursor:pointer;text-align:center;" title="Click to expand">
                <div id="aht-compact-dag" style="font-size:14px;font-weight:bold;color:#00d4ff;">—</div>
                <div id="aht-compact-timer" style="font-size:10px;color:#aaa;">00:00</div>
                <div id="aht-compact-today" style="font-size:8px;color:#888;margin-top:2px;">—</div>
            </div>`;
            // Initialize compact today stats
            const todayInit = document.getElementById('aht-compact-today');
            if (todayInit) { const c = getTodayCaseCount(); const s = getTodayStats(); todayInit.textContent = `📅 ${c} cases | ${s ? s.weightedDAG + '%' : '—'}`; }
            document.getElementById('aht-compact-view').addEventListener('click', () => {
                compactMode = false;
                safeSetStorage('aht_compact_mode_v3', JSON.stringify(false));
                if (compactInterval) { clearInterval(compactInterval); compactInterval = null; }
                panel.remove();
                buildPanel();
            });
            compactInterval = setInterval(() => {
                const dagEl = document.getElementById('aht-compact-dag');
                const timerEl = document.getElementById('aht-compact-timer');
                const todayEl = document.getElementById('aht-compact-today');
                if (!dagEl) return;
                if (isRunning) {
                    const dag = calcDAG(elapsedSeconds + STARTUP_DELAY_SECONDS, currentCaseType);
                    dagEl.textContent = dag ? dag + '%' : '—';
                    dagEl.style.color = dag ? (parseFloat(dag) >= 100 ? '#2ecc71' : parseFloat(dag) >= 80 ? '#f39c12' : '#e74c3c') : '#00d4ff';
                } else {
                    dagEl.textContent = '⏸';
                    dagEl.style.color = '#7f8c8d';
                }
                if (timerEl) timerEl.textContent = isRunning ? formatTime(elapsedSeconds) : '--:--';
                if (todayEl && elapsedSeconds % 30 === 0) {
                    const count = getTodayCaseCount();
                    const stats = getTodayStats();
                    todayEl.textContent = `📅 ${count} cases | ${stats ? stats.weightedDAG + '%' : '—'}`;
                }
            }, 1000);
        } else {
            panel.remove();
            buildPanel();
        }
    }

    function buildPanel() {
        const existing = document.getElementById('aht-tracker-panel');
        if (existing && document.body?.contains(existing)) return;
        if (existing) existing.remove();
        if (!document.body) return;
        const { position, size } = loadPanelState();
        isMinimized = loadMinimizedState();
        const caseIdDisplay = isCaseIdValid ? currentCaseId : '❌ NOT DETECTED';
        const panel = document.createElement('div');
        panel.id = 'aht-tracker-panel';
        panel.style.cssText = `position:fixed;bottom:20px;right:20px;width:260px;min-width:240px;background:#1a1a2e;color:#eaeaea;border-radius:12px;padding:0;font-family:Arial,sans-serif;font-size:13px;box-shadow:0 4px 20px rgba(0,0,0,0.5);z-index:99999;user-select:none;display:flex;flex-direction:column;border:1px solid #333;max-width:calc(100vw - 40px);max-height:calc(100vh - 40px);overflow:hidden;`;
        panel.innerHTML = `
            <div id="aht-panel-header" style="display:flex;justify-content:space-between;align-items:center;padding:12px 14px;border-bottom:1px solid #333;cursor:move;flex-shrink:0;background:#0f0f1a;border-radius:${isMinimized?'12px':'12px 12px 0 0'};">
                <strong style="font-size:14px;white-space:nowrap;">⏱ OTC AHT TRACKER</strong>
                <div style="display:flex;gap:6px;align-items:center;flex-shrink:0;">
                    <span id="aht-case-type-badge" style="font-size:10px;font-weight:bold;padding:3px 8px;border-radius:10px;background:#2980b9;color:#fff;white-space:nowrap;">Non-Email</span>
                    <button id="aht-btn-minimize" style="background:none;border:none;color:#00d4ff;cursor:pointer;font-size:18px;padding:6px 8px;font-weight:bold;white-space:nowrap;" title="Minimize to compact mode">📌</button>
                </div>
            </div>
            <div id="aht-minimized-section" style="display:${isMinimized?'flex':'none'};flex-direction:column;align-items:center;justify-content:center;padding:8px 12px;gap:4px;">
                <div id="aht-minimized-timer-display" style="font-size:28px;font-weight:bold;letter-spacing:2px;color:#00d4ff;line-height:1;">00:00</div>
                <div id="aht-minimized-info" style="font-size:9px;color:#888;text-align:center;">Click expand to view details</div>
            </div>
            <div id="aht-panel-content" style="padding:12px 14px;overflow-y:auto;overflow-x:hidden;flex:1;display:${isMinimized?'none':'flex'};flex-direction:column;gap:8px;">
                <div style="display:grid;grid-template-columns:1fr;gap:2px;font-size:9px;">
                    <div id="aht-case-label" style="color:${isCaseIdValid?'#aaa':'#e74c3c'};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:${isCaseIdValid?'normal':'bold'};">Case: ${caseIdDisplay}</div>
                    <div id="aht-queue-label" style="color:#888;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">Queue: detecting...</div>
                </div>
                <div style="display:grid;grid-template-columns:1fr;gap:6px;text-align:center;padding:4px 0;border:1px solid #333;border-radius:6px;background:#0f0f1a;">
                    <div id="aht-timer-display" style="font-size:clamp(28px,8vw,36px);font-weight:bold;letter-spacing:3px;color:#00d4ff;line-height:1;margin:8px 0 2px 0;">00:00</div>
                    <div id="aht-goal-label" style="font-size:10px;color:#888;margin:0 0 4px 0;">Goal: 8:00</div>
                    <div id="aht-status-bar" style="height:6px;border-radius:4px;background:#00d4ff;width:0%;transition:width 0.5s;margin:0 8px 8px 8px;"></div>
                    <div id="aht-dag-display" style="font-size:11px;color:#aaa;margin:0 0 6px 0;">DAG: —</div>
                </div>
                <div id="aht-status-msg" style="text-align:center;font-size:10px;color:${isCaseIdValid?'#aaa':'#e74c3c'};padding:4px;border-radius:4px;background:#16213e;min-height:18px;font-weight:${isCaseIdValid?'normal':'bold'};">${isCaseIdValid?'🚀 Loading...':'❌ Case ID Not Detected'}</div>
                <div id="aht-today-quick" style="text-align:center;font-size:9px;color:#888;padding:2px 4px;background:#0f0f1a;border-radius:4px;">📅 Today: 0 cases | DAG: —</div>
                <div style="display:grid;grid-template-columns:1fr;gap:4px;margin-top:2px;">
                    <input id="aht-case-note" type="text" placeholder="Add note (optional)..." maxlength="100" style="width:100%;padding:6px 8px;border:1px solid #444;border-radius:6px;background:#0f0f1a;color:#eaeaea;font-size:10px;box-sizing:border-box;"/>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:2px;">
                    <button id="aht-btn-stop" style="background:#e74c3c;color:#fff;border:none;border-radius:6px;padding:10px 8px;cursor:pointer;font-size:12px;font-weight:bold;transition:background 0.3s;width:100%;box-sizing:border-box;" ${isCaseIdValid?'':'disabled'}>⏹ STOP</button>
                    <button id="aht-btn-tracking-toggle" style="background:${trackingEnabled?'#27ae60':'#7f8c8d'};color:#fff;border:none;border-radius:6px;padding:10px 8px;cursor:pointer;font-size:12px;font-weight:bold;transition:background 0.3s;width:100%;box-sizing:border-box;">${trackingEnabled?'🟢 Online':'🔴 Offline'}</button>
                </div>
                <div style="display:grid;grid-template-columns:1fr;gap:6px;">
                    <button id="aht-btn-undo" style="background:#f1c40f;color:#000;border:none;border-radius:5px;padding:6px 8px;cursor:pointer;font-size:10px;font-weight:bold;display:none;">↶ UNDO</button>
                </div>
                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-top:2px;">
                    <button id="aht-btn-log" style="background:#2980b9;color:#fff;border:none;border-radius:5px;padding:6px 4px;cursor:pointer;font-size:10px;font-weight:bold;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">📋 Log</button>
                    <button id="aht-btn-stats" style="background:#16a085;color:#fff;border:none;border-radius:5px;padding:6px 4px;cursor:pointer;font-size:10px;font-weight:bold;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">📊 Stats</button>
                    <button id="aht-btn-help" style="background:#27ae60;color:#fff;border:none;border-radius:5px;padding:6px 4px;cursor:pointer;font-size:10px;font-weight:bold;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">❓ Help</button>
                </div>
                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:5px;">
                    <button id="aht-btn-edit-goals" style="background:#f39c12;color:#fff;border:none;border-radius:5px;padding:6px 4px;cursor:pointer;font-size:10px;font-weight:bold;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">⚙️ Goals</button>
                    <button id="aht-btn-clear" style="background:#7f8c8d;color:#fff;border:none;border-radius:5px;padding:6px 4px;cursor:pointer;font-size:10px;font-weight:bold;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">🗑 Clear</button>
                    <button id="aht-btn-export" style="background:#27ae60;color:#fff;border:none;border-radius:5px;padding:6px 4px;cursor:pointer;font-size:10px;font-weight:bold;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">📥 Export</button>
                </div>

                <div id="aht-export-panel" style="display:none;background:#0f0f1a;border-radius:6px;padding:10px;border:2px solid #27ae60;margin-top:6px;">
                    <div style="color:#27ae60;font-weight:bold;font-size:11px;margin-bottom:8px;">📥 EXPORT OPTIONS</div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                        <div><label style="color:#aaa;font-size:9px;display:block;margin-bottom:3px;">From:</label>
                            <input id="aht-export-from" type="date" style="width:100%;padding:4px;border:1px solid #444;border-radius:4px;background:#1a1a2e;color:#00d4ff;font-size:10px;box-sizing:border-box;"/></div>
                        <div><label style="color:#aaa;font-size:9px;display:block;margin-bottom:3px;">To:</label>
                            <input id="aht-export-to" type="date" style="width:100%;padding:4px;border:1px solid #444;border-radius:4px;background:#1a1a2e;color:#00d4ff;font-size:10px;box-sizing:border-box;"/></div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;margin-top:8px;">
                        <button id="aht-btn-export-filtered" style="background:#27ae60;color:#fff;border:none;border-radius:4px;padding:8px;cursor:pointer;font-size:10px;font-weight:bold;">📥 Range</button>
                        <button id="aht-btn-export-all" style="background:#2980b9;color:#fff;border:none;border-radius:4px;padding:8px;cursor:pointer;font-size:10px;font-weight:bold;">📥 All</button>
                        <button id="aht-btn-export-csv" style="background:#7f8c8d;color:#fff;border:none;border-radius:4px;padding:8px;cursor:pointer;font-size:10px;font-weight:bold;">📄 CSV</button>
                    </div>
                </div>
                <div id="aht-stats-panel" style="display:none;max-height:300px;overflow-y:auto;background:#0f0f1a;border-radius:6px;padding:8px;font-size:10px;border:1px solid #333;margin-top:6px;"></div>
                <div id="aht-goals-editor-panel" style="display:none;background:#0f0f1a;border-radius:6px;padding:10px;border:2px solid #f39c12;margin-top:6px;max-height:400px;overflow-y:auto;">
                    <div style="color:#f39c12;font-weight:bold;font-size:11px;margin-bottom:8px;">⚙️ EDIT GOALS (minutes)</div>
                    <div style="margin-bottom:6px;border:1px solid #2980b9;border-radius:6px;overflow:hidden;">
                        <div class="aht-goal-folder" data-target="aht-folder-gwf" style="background:#2980b9;color:#fff;padding:6px 8px;cursor:pointer;font-size:10px;font-weight:bold;">📁 GWF (click to expand)</div>
                        <div id="aht-folder-gwf" style="display:none;padding:8px;display:grid;grid-template-columns:1fr;gap:6px;">
                            <div><label style="color:#00d4ff;font-size:9px;display:block;margin-bottom:2px;font-weight:bold;">Email:</label>
                                <input id="aht-goal-email-input" type="number" step="0.1" min="0.1" max="60" style="width:100%;padding:4px;border:1px solid #444;border-radius:4px;background:#1a1a2e;color:#00d4ff;font-size:10px;box-sizing:border-box;"/></div>
                            <div><label style="color:#2980b9;font-size:9px;display:block;margin-bottom:2px;font-weight:bold;">Non-Email:</label>
                                <input id="aht-goal-nonemail-input" type="number" step="0.1" min="0.1" max="60" style="width:100%;padding:4px;border:1px solid #444;border-radius:4px;background:#1a1a2e;color:#2980b9;font-size:10px;box-sizing:border-box;"/></div>
                        </div>
                    </div>
                    <div style="margin-bottom:6px;border:1px solid #c0392b;border-radius:6px;overflow:hidden;">
                        <div class="aht-goal-folder" data-target="aht-folder-fallback" style="background:#c0392b;color:#fff;padding:6px 8px;cursor:pointer;font-size:10px;font-weight:bold;">📁 Fallback (click to expand)</div>
                        <div id="aht-folder-fallback" style="display:none;padding:8px;display:grid;grid-template-columns:1fr;gap:6px;">
                            <div><label style="color:#c0392b;font-size:9px;display:block;margin-bottom:2px;font-weight:bold;">Fallback:</label>
                                <input id="aht-goal-photon-input" type="number" step="0.1" min="0.1" max="60" style="width:100%;padding:4px;border:1px solid #444;border-radius:4px;background:#1a1a2e;color:#c0392b;font-size:10px;box-sizing:border-box;"/></div>
                        </div>
                    </div>
                    <div style="margin-bottom:6px;border:1px solid #e67e22;border-radius:6px;overflow:hidden;">
                        <div class="aht-goal-folder" data-target="aht-folder-muckout" style="background:#e67e22;color:#fff;padding:6px 8px;cursor:pointer;font-size:10px;font-weight:bold;">📁 Muckout (click to expand)</div>
                        <div id="aht-folder-muckout" style="display:none;padding:8px;display:grid;grid-template-columns:1fr;gap:6px;">
                            <div><label style="color:#e67e22;font-size:9px;display:block;margin-bottom:2px;font-weight:bold;">Buyer Abuse Check:</label>
                                <input id="aht-goal-muckout-bac-input" type="number" step="0.01" min="0.1" max="60" style="width:100%;padding:4px;border:1px solid #444;border-radius:4px;background:#1a1a2e;color:#e67e22;font-size:10px;box-sizing:border-box;"/></div>
                            <div><label style="color:#e67e22;font-size:9px;display:block;margin-bottom:2px;font-weight:bold;">Related Claim Check:</label>
                                <input id="aht-goal-muckout-rcc-input" type="number" step="0.01" min="0.1" max="60" style="width:100%;padding:4px;border:1px solid #444;border-radius:4px;background:#1a1a2e;color:#e67e22;font-size:10px;box-sizing:border-box;"/></div>
                            <div><label style="color:#e67e22;font-size:9px;display:block;margin-bottom:2px;font-weight:bold;">Manual Action:</label>
                                <input id="aht-goal-muckout-ma-input" type="number" step="0.01" min="0.1" max="60" style="width:100%;padding:4px;border:1px solid #444;border-radius:4px;background:#1a1a2e;color:#e67e22;font-size:10px;box-sizing:border-box;"/></div>
                            <div><label style="color:#e67e22;font-size:9px;display:block;margin-bottom:2px;font-weight:bold;">Refund Eligibility:</label>
                                <input id="aht-goal-muckout-re-input" type="number" step="0.01" min="0.1" max="60" style="width:100%;padding:4px;border:1px solid #444;border-radius:4px;background:#1a1a2e;color:#e67e22;font-size:10px;box-sizing:border-box;"/></div>
                        </div>
                    </div>
                    <div style="margin-bottom:6px;border:1px solid #9b59b6;border-radius:6px;overflow:hidden;">
                        <div class="aht-goal-folder" data-target="aht-folder-photoncore" style="background:#9b59b6;color:#fff;padding:6px 8px;cursor:pointer;font-size:10px;font-weight:bold;">📁 Photon Core (click to expand)</div>
                        <div id="aht-folder-photoncore" style="display:none;padding:8px;display:grid;grid-template-columns:1fr;gap:6px;" >
                            <div id="aht-photoncore-goals-list"></div>
                        </div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:8px;">
                        <button id="aht-btn-save-goals" style="background:#27ae60;color:#fff;border:none;border-radius:4px;padding:8px;cursor:pointer;font-size:10px;font-weight:bold;">💾 Save</button>
                        <button id="aht-btn-reset-goals" style="background:#e74c3c;color:#fff;border:none;border-radius:4px;padding:8px;cursor:pointer;font-size:10px;font-weight:bold;">🔄 Reset</button>
                    </div>
                </div>
                <div id="aht-log-panel" style="display:none;max-height:300px;overflow-y:auto;background:#0f0f1a;border-radius:6px;padding:8px;font-size:10px;border:1px solid #333;margin-top:6px;"></div>
                <div id="aht-help-panel" style="display:none;max-height:300px;overflow-y:auto;background:#0f0f1a;border-radius:6px;padding:10px;font-size:10px;line-height:1.5;border:1px solid #333;margin-top:6px;"></div>
            </div>
            <div id="aht-resize-handle" style="position:absolute;bottom:0;right:0;width:20px;height:20px;cursor:nwse-resize;background:linear-gradient(135deg,transparent 40%,#00d4ff 40%);border-radius:0 0 12px 0;opacity:0.5;flex-shrink:0;display:${isMinimized?'none':'block'};"></div>`;
        document.body.appendChild(panel);
        const style = document.createElement('style');
        style.textContent = `@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.6}}@keyframes trackingGlow{0%,100%{text-shadow:0 0 4px rgba(0,212,255,0.3)}50%{text-shadow:0 0 8px rgba(0,212,255,0.6)}}#aht-tracker-panel{scrollbar-width:thin;scrollbar-color:#444 #1a1a2e}#aht-tracker-panel::-webkit-scrollbar{width:6px}#aht-tracker-panel::-webkit-scrollbar-track{background:#1a1a2e}#aht-tracker-panel::-webkit-scrollbar-thumb{background:#444;border-radius:3px}#aht-tracker-panel button:hover:not(:disabled){opacity:0.85;transform:scale(1.02);transition:all 0.2s}#aht-tracker-panel button:disabled{opacity:0.5;cursor:not-allowed}#aht-timer-display.tracking{animation:trackingGlow 2s ease-in-out infinite}`;
        document.head.appendChild(style);
        setTimeout(() => {
            cacheDOMElements(); attachEvents(); attachDragResize(); refreshCaseType(); updateDisplay(); applyTheme(); updateTodayQuick();
            // Restore pin position
            const savedPin = safeGetStorage('aht_pin_position_v3', 'right');
            if (savedPin === 'left') { const p = document.getElementById('aht-tracker-panel'); if (p) { p.style.left = '20px'; p.style.right = 'auto'; } }
        }, 100);
    }


    // ═══════════════════════════════════════════════════════════════════
    // 🖱️ DRAG & RESIZE
    // ═══════════════════════════════════════════════════════════════════

    function attachDragResize() {
        const panel = document.getElementById('aht-tracker-panel');
        const header = document.getElementById('aht-panel-header');
        const resizeHandle = document.getElementById('aht-resize-handle');
        if (!panel || !header) return;

        // Double-click header to toggle size
        header.addEventListener('dblclick', (e) => {
            if (e.target.tagName === 'BUTTON') return;
            const rect = panel.getBoundingClientRect();
            if (rect.width > 300) {
                panel.style.width = '240px';
                panel.style.height = 'auto';
            } else {
                panel.style.width = '320px';
                panel.style.height = '500px';
            }
            savePanelState(panel);
        });

        const onMouseDown = (e) => {
            if (e.target.tagName === 'BUTTON' || e.target.tagName === 'INPUT') return;
            e.preventDefault();
            isDragging = true;
            dragOffsetX = e.clientX - panel.getBoundingClientRect().left;
            dragOffsetY = e.clientY - panel.getBoundingClientRect().top;
            document.body.style.userSelect = 'none';
            document.body.style.pointerEvents = 'none';
            panel.style.pointerEvents = 'auto';
            panel.style.willChange = 'left, top';
            panel.setPointerCapture(e.pointerId);
        };
        const onMouseMove = (e) => {
            if (!isDragging && !isResizing) return;
            e.preventDefault();
            if (isDragging) {
                panel.style.left = (e.clientX - dragOffsetX) + 'px';
                panel.style.top = (e.clientY - dragOffsetY) + 'px';
                panel.style.bottom = 'auto'; panel.style.right = 'auto';
            }
            if (isResizing) {
                panel.style.width = Math.max(240, resizeStartWidth + (e.clientX - resizeStartX)) + 'px';
                panel.style.height = Math.max(200, resizeStartHeight + (e.clientY - resizeStartY)) + 'px';
            }
        };
        const onMouseUp = (e) => {
            if (isDragging || isResizing) {
                isDragging = false; isResizing = false;
                document.body.style.userSelect = '';
                document.body.style.pointerEvents = '';
                panel.style.pointerEvents = '';
                panel.style.willChange = '';
                try { panel.releasePointerCapture(e.pointerId); } catch(ex) {}
                savePanelState(panel);
            }
        };
        header.addEventListener('pointerdown', onMouseDown);
        document.addEventListener('pointermove', onMouseMove);
        document.addEventListener('pointerup', onMouseUp);
        if (resizeHandle) {
            resizeHandle.addEventListener('pointerdown', (e) => {
                e.preventDefault(); e.stopPropagation();
                isResizing = true;
                resizeStartX = e.clientX; resizeStartY = e.clientY;
                const r = panel.getBoundingClientRect();
                resizeStartWidth = r.width; resizeStartHeight = r.height;
                document.body.style.userSelect = 'none';
                document.body.style.pointerEvents = 'none';
                panel.style.pointerEvents = 'auto';
                panel.style.willChange = 'width, height';
                panel.setPointerCapture(e.pointerId);
            });
        }
        registerCleanup(() => {
            header.removeEventListener('pointerdown', onMouseDown);
            document.removeEventListener('pointermove', onMouseMove);
            document.removeEventListener('pointerup', onMouseUp);
        });
    }

    // ═══════════════════════════════════════════════════════════════════
    // 🔗 EVENT HANDLERS
    // ═══════════════════════════════════════════════════════════════════

    function toggleTracking() {
        const btn = document.getElementById('aht-btn-tracking-toggle');
        if (trackingEnabled) {
            trackingEnabled = false;
            safeSetStorage('aht_tracking_enabled_v3', JSON.stringify(false));
            if (isRunning) { clearInterval(timerInterval); timerInterval = null; isRunning = false; }
            elapsedSeconds = 0;
            if (DOM.display) { DOM.display.textContent = '00:00'; DOM.display.style.color = '#7f8c8d'; }
            if (DOM.bar) { DOM.bar.style.width = '0%'; DOM.bar.style.background = '#7f8c8d'; }
            if (DOM.dag) DOM.dag.textContent = 'DAG: —';
            if (btn) { btn.textContent = '🔴 Offline'; btn.style.background = '#7f8c8d'; }
            updateStatusMsg('⏸ Offline - not tracking', '#7f8c8d');
            setButtonStates(false);
        } else {
            trackingEnabled = true;
            safeSetStorage('aht_tracking_enabled_v3', JSON.stringify(true));
            if (btn) { btn.textContent = '🟢 Online'; btn.style.background = '#27ae60'; }
            updateStatusMsg('🟢 Online - tracking active', '#2ecc71');
            if (isCaseIdValid) startTimer();
        }
    }

    function attachEvents() {
        const handlers = [
            ['aht-btn-stop', 'click', stopTimer],
            ['aht-btn-minimize', 'click', toggleCompactMode],
            ['aht-btn-undo', 'click', undoLastDelete],
            ['aht-btn-stats', 'click', toggleStatsPanel],
            ['aht-btn-edit-goals', 'click', toggleGoalsEditor],
            ['aht-btn-save-goals', 'click', saveGoalsFromInputs],
            ['aht-btn-reset-goals', 'click', () => { if (confirm('Reset to defaults?')) resetGoalsToDefault(); }],
            ['aht-btn-tracking-toggle', 'click', toggleTracking],
            ['aht-btn-log', 'click', () => {
                const lp = document.getElementById('aht-log-panel');
                if (lp) {
                    if (lp.style.display === 'none') { closeAllPanels('aht-log-panel'); renderLog(); lp.style.display = 'block'; }
                    else lp.style.display = 'none';
                }
            }],
            ['aht-btn-help', 'click', displayHelpInstructions],
            ['aht-btn-clear', 'click', () => {
                if (confirm('Clear all logs?')) {
                    safeSetStorage(CONFIG.storage.log, JSON.stringify([]));
                    safeSetStorage(CONFIG.storage.excluded, JSON.stringify([]));
                    const lp = document.getElementById('aht-log-panel');
                    if (lp) lp.innerHTML = '<em>Log cleared.</em>';
                    updateStatusMsg('✅ Logs cleared', '#2ecc71');
                }
            }],
            ['aht-btn-export', 'click', () => {
                const ep = document.getElementById('aht-export-panel');
                if (ep) {
                    if (ep.style.display === 'none') {
                        closeAllPanels('aht-export-panel');
                        ep.style.display = 'block';
                        const fromEl = document.getElementById('aht-export-from');
                        const toEl = document.getElementById('aht-export-to');
                        if (fromEl && !fromEl.value) fromEl.value = getTodayDate();
                        if (toEl && !toEl.value) toEl.value = getTodayDate();
                    } else ep.style.display = 'none';
                }
            }],
            ['aht-btn-export-all', 'click', () => exportToExcel()],
            ['aht-btn-export-csv', 'click', exportToCSV],
            ['aht-btn-export-filtered', 'click', () => {
                const from = document.getElementById('aht-export-from')?.value;
                const to = document.getElementById('aht-export-to')?.value;
                if (!from || !to) { alert('Please select both dates'); return; }
                exportToExcel(from, to);
            }]
        ];
        handlers.forEach(([id, event, handler]) => {
            const el = document.getElementById(id);
            if (el) { el.removeEventListener(event, handler); el.addEventListener(event, handler); }
        });
    }

    // ═══════════════════════════════════════════════════════════════════
    // ⭐ MUTATION OBSERVER
    // ═══════════════════════════════════════════════════════════════════

    function setupMutationObserver() {
        if (mutationObserver) { mutationObserver.disconnect(); mutationObserver = null; }
        mutationObserver = new MutationObserver(() => {
            try {
                if (!document.getElementById('aht-tracker-panel')) {
                    if (rebuildTimeout) clearTimeout(rebuildTimeout);
                    rebuildTimeout = setTimeout(() => {
                        if (!document.getElementById('aht-tracker-panel')) {
                            if (compactMode) {
                                // Rebuild panel then switch to compact
                                buildPanel();
                                setTimeout(toggleCompactMode, 200);
                            } else {
                                buildPanel();
                            }
                        }
                    }, CONFIG.timers.panelRebuild);
                }
                const newUrl = location.href;
                if (newUrl !== lastUrl) {
                    if (urlCheckTimeout) clearTimeout(urlCheckTimeout);
                    urlCheckTimeout = setTimeout(() => {
                        lastUrl = newUrl;
                        const newCaseId = detectCaseId();
                        const newValid = isValidCaseId(newCaseId);
                        const isSame = newValid && isCaseIdValid && normalizeAndCompareCaseIds(newCaseId, currentCaseId);
                        if (isSame) {
                            refreshCaseType();
                            if (!isRunning) startTimer();
                        } else if (!isRunning || (newValid && newCaseId !== manuallyStoppedOnCase)) {
                            if (elapsedSeconds > 0 && isCaseIdValid) {
                                saveLog(calcDAG(elapsedSeconds + STARTUP_DELAY_SECONDS, currentCaseType));
                                lastSavedCaseId = currentCaseId;
                            }
                            currentCaseId = newCaseId; isCaseIdValid = newValid;
                            elapsedSeconds = 0;
                            if (DOM.display) DOM.display.textContent = '00:00';
                            if (DOM.dag) DOM.dag.textContent = 'DAG: —';
                            updateStatusMsg(isCaseIdValid ? '🚀 New case!' : '❌ Case ID Not Detected', isCaseIdValid ? '#aaa' : '#e74c3c');
                            setTimeout(() => {
                                manuallyStoppedOnCase = null; refreshCaseType();
                                if (isCaseIdValid) startTimer(); else setButtonStates(false);
                            }, CONFIG.timers.caseChangeDelay);
                        }
                    }, 300);
                }
            } catch (e) {}
        });
        mutationObserver.observe(document, { subtree: false, childList: true });
        registerCleanup(() => { if (mutationObserver) { mutationObserver.disconnect(); mutationObserver = null; } });
    }

    // ═══════════════════════════════════════════════════════════════════
    // 🧭 PAGE UNLOAD HANDLER
    // ═══════════════════════════════════════════════════════════════════

    function setupPageUnloadHandler() {
        const handler = () => saveUnloadState();
        window.addEventListener('beforeunload', handler);
        registerCleanup(() => window.removeEventListener('beforeunload', handler));

        // Keep panel visible when moving to smaller screen
        const onResize = () => {
            const panel = document.getElementById('aht-tracker-panel');
            if (!panel) return;
            const rect = panel.getBoundingClientRect();
            if (rect.right > window.innerWidth || rect.bottom > window.innerHeight || rect.left < 0 || rect.top < 0) {
                panel.style.bottom = '20px';
                panel.style.right = '20px';
                panel.style.top = 'auto';
                panel.style.left = 'auto';
            }
        };
        window.addEventListener('resize', onResize);
        registerCleanup(() => window.removeEventListener('resize', onResize));
    }

    // ═══════════════════════════════════════════════════════════════════
    // 🎯 INITIALIZATION
    // ═══════════════════════════════════════════════════════════════════

    async function initialize() {
        if (!document.body) { setTimeout(initialize, 200); return; }
        console.log('  ✨ Initializing AHT Tracker v3.3.14 - Chrome Extension');

        // Wait for storage cache to be ready
        await _initStorageCache();

        currentCaseId = detectCaseId();
        isCaseIdValid = isValidCaseId(currentCaseId);

        loadGoals();
        // Restore tracking state
        const savedTracking = safeGetStorage('aht_tracking_enabled_v3', true);
        trackingEnabled = savedTracking !== false;
        // Restore UI preferences
        const savedTheme = safeGetStorage('aht_theme_v3', 'dark');
        currentTheme = savedTheme || 'dark';
        const savedCompact = safeGetStorage('aht_compact_mode_v3', true);
        compactMode = savedCompact !== false;
        restoreAndLogUnloadState();
        const timerRestored = restoreTimerState();
        buildPanel();
        if (compactMode) {
            compactMode = false; // toggleCompactMode will flip it back to true
            toggleCompactMode();
        }
        setupPageUnloadHandler();
        setupMutationObserver();
        setupIdleDetection();
        setupKeyboardShortcuts();
        updateTodayQuick();

        if (timerRestored && isRunning && isCaseIdValid) {
            setTimeout(() => {
                timerInterval = setInterval(() => {
                    try { elapsedSeconds = Math.floor((Date.now() - startTime) / 1000); updateDisplay(); saveTimerState(); if (elapsedSeconds % 30 === 0) updateTodayQuick(); } catch (e) {}
                }, CONFIG.timers.updateFrequency);
                setButtonStates(true); updateDisplay(); updateStatusMsg('🟢 Resumed', '#2ecc71');
                pageLoadInitialized = true;
            }, 500);
        } else if (shouldAutoStartOnLoad && !pageLoadInitialized && isCaseIdValid) {
            setTimeout(() => { startTimer(); pageLoadInitialized = true; }, 500);
        } else {
            pageLoadInitialized = true;
        }
        console.log('  🎉 AHT Tracker v3.3.14 Ready! (Chrome Extension)');

        // Retry case type detection - page content loads dynamically
        const retryDetection = () => {
            if ((currentCaseType === 'nonemail' || currentCaseType === 'photon' || currentCaseType === 'muckout') && isCaseIdValid) {
                const prevType = currentCaseType;
                const prevQueue = currentQueueName;
                detectCaseType();
                console.log('🔄 [RETRY] Result:', currentCaseType, '| Queue:', currentQueueName);
                // Update goal and UI without resetting timer
                currentGoal = AHT_GOALS[currentCaseType];
                updateCaseTypeUI();
                // If timer not running, start it
                if (!isRunning) {
                    startTimer();
                }
            }
        };
        setTimeout(retryDetection, 3000);
        setTimeout(retryDetection, 6000);
        setTimeout(retryDetection, 10000);
        setTimeout(retryDetection, 15000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }

})();
